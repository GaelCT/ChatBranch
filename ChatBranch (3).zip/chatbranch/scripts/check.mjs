import {readdir,readFile,access} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
const root=resolve(import.meta.dirname,'..');
async function files(dir){let out=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())out.push(...await files(p));else out.push(p);}return out;}
const manifest=JSON.parse(await readFile(join(root,'extension/manifest.json'),'utf8'));
for(const f of [manifest.background.service_worker,manifest.side_panel.default_path,...manifest.content_scripts.flatMap(c=>c.js)])await access(join(root,'extension',f));
const scripts=(await files(join(root,'extension'))).filter(p=>p.endsWith('.js'));
for(const p of scripts){const r=spawnSync(process.execPath,['--check',p],{encoding:'utf8'});if(r.status!==0)throw new Error(r.stderr);}
const html=await readFile(join(root,'extension/panel.html'),'utf8'),panel=await readFile(join(root,'extension/panel.js'),'utf8');
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
if(ids.length!==new Set(ids).size)throw new Error('Duplicate HTML IDs');
for(const m of panel.matchAll(/\$\('([^']+)'\)/g))if(!ids.includes(m[1]))throw new Error('Missing panel element: '+m[1]);
for(const p of scripts)if(/\b(?:eval|new Function)\s*\(|\.innerHTML\s*=/.test(await readFile(p,'utf8')))throw new Error('Unexpected dynamic code or unsafe HTML in '+p);
console.log(`Verified manifest assets, ${scripts.length} JavaScript files, and ${ids.length} panel elements.`);
