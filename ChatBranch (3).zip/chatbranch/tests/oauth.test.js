import test from 'node:test';
import assert from 'node:assert/strict';
import {startDevice,pollDevice,DEVICE_GRANT} from '../extension/core/oauth.js';
const clientId='Ov23_exampleclient';
function fetchJSON(result,calls){return async(url,options)=>{calls.push({url,...options});return new Response(JSON.stringify(result),{status:200,headers:{'content-type':'application/json'}});};}
test('device sign in uses only client ID and requested scopes, no secret',async()=>{
  const calls=[];const device=await startDevice(clientId,true,fetchJSON({device_code:'device-secret',user_code:'ABCD-EFGH',verification_uri:'https://evil.test',interval:5,expires_in:900},calls),1000);
  const params=new URLSearchParams(calls[0].body);assert.equal(params.get('client_id'),clientId);assert.equal(params.get('scope'),'public_repo workflow');assert.equal(params.has('client_secret'),false);assert.equal(device.verificationUrl,'https://github.com/login/device');assert.equal(device.nextPoll,6000);
});
test('respect polling interval, pending, slow_down and expiry',async()=>{
  const d={clientId,deviceCode:'secret',interval:5,nextPoll:5000,expiresAt:100000};const calls=[];
  assert.deepEqual(await pollDevice(d,fetchJSON({},calls),1000),{device:d});assert.equal(calls.length,0);
  const pending=await pollDevice(d,fetchJSON({error:'authorization_pending'},calls),5000);assert.equal(pending.device.nextPoll,10000);
  const slow=await pollDevice(pending.device,fetchJSON({error:'slow_down'},calls),10000);assert.equal(slow.device.interval,10);assert.equal(slow.device.nextPoll,20000);
  assert.match((await pollDevice(d,fetchJSON({},calls),100000)).error,/expired/);
});
test('token grant is device flow; denial errors are actionable',async()=>{
  const d={clientId,deviceCode:'secret',interval:5,nextPoll:0,expiresAt:100000};const calls=[];
  const r=await pollDevice(d,fetchJSON({access_token:'test-token',scope:'public_repo'},calls),1);assert.equal(r.token,'test-token');assert.equal(new URLSearchParams(calls[0].body).get('grant_type'),DEVICE_GRANT);assert(!calls[0].body.includes('client_secret'));
  assert.match((await pollDevice(d,fetchJSON({error:'access_denied'},[]),1)).error,/declined/);
  await assert.rejects(startDevice(clientId,false,fetchJSON({error:'device_flow_disabled'},[])),/Enable Device Flow/);
});
