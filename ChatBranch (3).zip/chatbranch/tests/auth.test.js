import test from 'node:test';
import assert from 'node:assert/strict';
import {AuthManager,VERIFY_TTL} from '../extension/core/auth.js';
function storage(seed={}){const data=structuredClone(seed);return {data,async setAccessLevel({accessLevel}){this.access=accessLevel;},async get(key){return structuredClone(key===null?data:Object.fromEntries((Array.isArray(key)?key:[key]).filter(k=>k in data).map(k=>[k,data[k]])));},async set(value){Object.assign(data,structuredClone(value));},async remove(key){for(const k of Array.isArray(key)?key:[key])delete data[k];},async clear(){for(const k of Object.keys(data))delete data[k];}};}
const credentials={token:'test-only-secret',scope:'public_repo workflow',expiresAt:null};
function fixture(){
  const local=storage(),session=storage(),calls=[];let time=1000000,mode='ok',scopes='public_repo, workflow',release;
  const fetcher=async(url,options)=>{
    calls.push({url,options});if(mode==='wait')await new Promise(resolve=>{release=resolve;});
    if(mode==='offline')throw new TypeError('Failed to fetch');
    return new Response(JSON.stringify(mode==='revoked'?{message:'Bad credentials'}:{login:'GaelCT'}),{status:mode==='revoked'?401:200,headers:{'content-type':'application/json','x-oauth-scopes':scopes}});
  };
  const make=()=>new AuthManager({local,session,fetcher,now:()=>time});
  return {local,session,calls,make,setMode:v=>{mode=v;},setScopes:v=>{scopes=v;},advance:ms=>{time+=ms;},release:()=>release?.()};
}
test('persistent credentials survive a cleared session and are verified without device OAuth',async()=>{
  const f=fixture();let manager=f.make();await manager.accept(credentials);assert.equal(f.local.access,'TRUSTED_CONTEXTS');assert.equal(f.session.access,'TRUSTED_CONTEXTS');assert.equal(f.local.data.githubAuth.token,credentials.token);assert.equal(f.session.data.auth,undefined);
  await f.session.clear();manager=f.make();assert.equal((await manager.status()).state,'checking');assert.equal(await manager.user(),null);
  await manager.verify();assert.equal((await manager.user()).login,'GaelCT');assert(f.calls.every(c=>c.url==='https://api.github.com/user'));assert.equal(f.calls.length,2);assert(!JSON.stringify(await manager.status()).includes(credentials.token));
});
test('reopening the workspace reuses fresh verification and refreshes it after five minutes',async()=>{
  const f=fixture(),manager=f.make();await manager.accept(credentials);await manager.verify();await manager.verify();assert.equal(f.calls.length,1);
  f.advance(VERIFY_TTL+1);assert.equal((await manager.status()).state,'checking');assert.equal(await manager.user(),null);await manager.verify();assert.equal(f.calls.length,2);assert.equal((await manager.status()).state,'connected');
});
test('an offline verification retains the credential and never claims connected',async()=>{
  const f=fixture(),manager=f.make();await manager.accept(credentials);f.setMode('offline');await manager.verify({force:true});
  assert.equal((await manager.status()).state,'unreachable');assert.equal(await manager.user(),null);assert.equal(f.local.data.githubAuth.token,credentials.token);const count=f.calls.length;
  await manager.verify();assert.equal(f.calls.length,count);f.advance(31000);f.setMode('ok');await manager.verify();assert.equal((await manager.status()).state,'connected');assert.equal(f.local.data.githubAuth.token,credentials.token);
});
test('revoked tokens are removed and reauthentication is requested only after rejection',async()=>{
  const f=fixture(),manager=f.make();await manager.accept(credentials);f.setMode('revoked');await manager.verify({force:true});
  assert.equal(f.local.data.githubAuth,undefined);assert.equal((await manager.status()).state,'reauth_required');assert.equal((await manager.status()).apiReachable,true);assert.equal(await manager.user(),null);
});
test('GitHub scope response controls publish permission independently of identity',async()=>{
  const f=fixture(),manager=f.make();f.setScopes('');await manager.accept(credentials);const status=await manager.status();assert.equal(status.state,'connected');assert.equal(status.canPublish,false);assert.equal(status.workflow,false);await assert.rejects(manager.require(),/public_repo/);
});
test('expired credentials request reauthentication without making a network request',async()=>{
  const f=fixture(),manager=f.make();await manager.accept({...credentials,expiresAt:1000001});f.advance(2);const count=f.calls.length;await manager.verify();assert.equal(f.calls.length,count);assert.equal(f.local.data.githubAuth,undefined);assert.equal((await manager.status()).state,'reauth_required');
});
test('logout while verification is pending cannot restore the saved account',async()=>{
  const f=fixture(),manager=f.make();await manager.accept(credentials);f.setMode('wait');const checking=manager.verify({force:true});await new Promise(resolve=>setImmediate(resolve));await manager.clear();f.setMode('ok');f.release();await checking;assert.equal(f.local.data.githubAuth,undefined);assert.equal((await manager.status()).state,'signed_out');
});
test('old session-only credentials migrate to private persistent storage',async()=>{
  const f=fixture();f.session.data.auth={...credentials,login:'GaelCT'};const manager=f.make();await manager.ready;assert.equal(f.local.data.githubAuth.token,credentials.token);assert.equal(f.session.data.auth,undefined);await manager.verify();assert.equal((await manager.status()).state,'connected');
});
test('a newly authorized token is remembered even if the initial identity check is offline',async()=>{
  const f=fixture(),manager=f.make();f.setMode('offline');await manager.accept(credentials);assert.equal(f.local.data.githubAuth.token,credentials.token);assert.equal((await manager.status()).state,'unreachable');f.setMode('ok');await manager.verify({force:true});assert.equal((await manager.status()).state,'connected');
});
test('simultaneous verification requests share one network check',async()=>{
  const f=fixture(),manager=f.make();await manager.accept(credentials);f.setMode('wait');const first=manager.verify({force:true}),second=manager.verify({force:true});await new Promise(resolve=>setImmediate(resolve));f.setMode('ok');f.release();await Promise.all([first,second]);assert.equal(f.calls.length,2);
});
