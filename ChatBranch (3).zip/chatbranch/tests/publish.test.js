import test from 'node:test';
import assert from 'node:assert/strict';
import {publishReview,writableTarget} from '../extension/core/publish.js';
import {GitHubError} from '../extension/core/github.js';
const base='a'.repeat(40),commit='b'.repeat(40);
const options={branch:'chatbranch/fix',title:'Fix behavior',message:'Fix and test',body:'Tests added',draft:true};
function review(push=true){return {snapshot:{fullName:'up/project',branch:'main',sha:base,treeSha:'original-tree',repo:{name:'project',default_branch:'main',permissions:{push}},entries:[{path:'src/a.js',mode:'100755'}]},files:[{path:'src/a.js',action:'write',content:'changed\n'},{path:'test/new.js',action:'write',content:'tests\n'}]};}
function mock(handler){const calls=[];return {calls,async request(path,options={}){calls.push({path,...options});return handler(path,options,calls);}};}
function ownMock({prFail=false,stale=false,update=false}={}){let created=false;return mock((p,o)=>{
  if(p.includes('/git/ref/heads/main'))return {object:{sha:stale?'c'.repeat(40):base}};
  if(p.includes('/git/ref/heads/chatbranch')){if(created||update)return {object:{sha:created?commit:base}};throw new GitHubError('missing',404);}
  if(p.endsWith('/git/trees'))return {sha:'new-tree'};
  if(p.endsWith('/git/commits'))return {sha:commit};
  if(p.includes('/git/refs')){created=true;return {};}
  if(p.includes('/pulls?'))return [];
  if(p.endsWith('/pulls')){if(prFail)throw new GitHubError('PR blocked',403);return {number:7,html_url:'https://github.com/up/project/pull/7'};}
  if(p.endsWith('/pulls/7'))return {number:7,html_url:'https://github.com/up/project/pull/7'};
  throw new Error('Unexpected '+p);
});}
test('one commit contains code and tests, preserves base tree and executable bit',async()=>{
  const api=ownMock();const result=await publishReview(api,review(),options,'me');
  const tree=api.calls.find(c=>c.path.endsWith('/git/trees'));assert.equal(tree.body.base_tree,'original-tree');assert.equal(tree.body.tree.length,2);assert.equal(tree.body.tree[0].mode,'100755');
  assert.deepEqual(api.calls.find(c=>c.path.endsWith('/git/commits')).body.parents,[base]);
  assert.deepEqual(api.calls.find(c=>c.path.endsWith('/git/refs')).body,{ref:'refs/heads/chatbranch/fix',sha:commit});assert.equal(result.number,7);
  assert(!api.calls.some(c=>c.method==='PATCH'));
});
test('stale base and default-branch target fail before mutation',async()=>{
  const api=ownMock({stale:true});await assert.rejects(publishReview(api,review(),options,'me'),/base branch changed/);assert(!api.calls.some(c=>c.method));
  await assert.rejects(publishReview(ownMock(),review(),{...options,branch:'main'},'me'),/new branch/);
});
test('fork creation waits for selected upstream commit; PR targets upstream',async()=>{
  let forkReads=0;
  const api=mock((p,o)=>{
    if(p==='/repos/up/project/git/ref/heads/main')return {object:{sha:base}};
    if(p==='/repos/me/project')throw new GitHubError('missing',404);
    if(p==='/repos/up/project/forks')return {full_name:'me/project'};
    if(p==='/repos/me/project/git/commits/'+base){if(++forkReads===1)throw new GitHubError('preparing',404);return {};}
    if(p.includes('/git/ref/heads/'))throw new GitHubError('missing',404);
    if(p.endsWith('/git/trees'))return {sha:'new-tree'};
    if(p.endsWith('/git/commits'))return {sha:commit};
    if(p.endsWith('/git/refs'))return {};
    if(p.includes('/pulls?'))return [];
    if(p==='/repos/up/project/pulls'){assert.equal(o.body.head,'me:chatbranch/fix');return {number:1,html_url:'https://github.com/up/project/pull/1'};}
    throw new Error('Unexpected '+p);
  });
  const result=await publishReview(api,review(false),options,'me',{delay:async()=>{}});assert.equal(result.target,'me/project');assert.equal(forkReads,2);assert(api.calls.some(c=>c.path==='/repos/up/project/forks'));
});
test('unrelated repo names are never used as forks',async()=>{
  const api=mock(p=>{if(p==='/repos/me/project'||p==='/repos/me/project-chatbranch')return {fork:false,permissions:{push:true}};throw new Error(p);});
  await assert.rejects(writableTarget(api,review(false).snapshot,'me'),/occupied/);assert(!api.calls.some(c=>c.method));
});
test('interrupted PR publication can retry without a duplicate commit',async()=>{
  const api=ownMock({prFail:true}),journal={};await assert.rejects(publishReview(api,review(),options,'me',{journal}),/PR blocked/);assert(journal.branchReady);const calls=api.calls.length;
  const original=api.request.bind(api);api.request=async(p,o)=>p.endsWith('/pulls')?{number:7,html_url:'https://github.com/up/project/pull/7'}:original(p,o);
  const result=await publishReview(api,review(),options,'me',{journal});assert.equal(result.number,7);assert(!api.calls.slice(calls).some(c=>c.path.endsWith('/git/commits')));
});
test('PR fix uses a fast-forward ref update and never force pushes',async()=>{
  const r=review();r.snapshot.branch='chatbranch/fix';r.snapshot.updatePR={upstream:'up/project',base:'main',number:7};
  const api=ownMock({update:true});const result=await publishReview(api,r,options,'me');
  const update=api.calls.find(c=>c.method==='PATCH');assert.deepEqual(update.body,{sha:commit,force:false});assert.equal(result.number,7);assert(!api.calls.some(c=>c.method==='POST'&&c.path.endsWith('/pulls')));
});
test('retry recognizes a ref write whose checkpoint response was lost',async()=>{
  const api=ownMock(),journal={target:'up/project',branch:options.branch,commit};
  const original=api.request.bind(api);api.request=async(p,o)=>p.includes('/git/ref/heads/chatbranch')?{object:{sha:commit}}:original(p,o);
  const result=await publishReview(api,review(),options,'me',{journal});assert.equal(result.number,7);assert(!api.calls.some(c=>c.path.includes('/git/refs')||c.path.endsWith('/git/commits')));
});
