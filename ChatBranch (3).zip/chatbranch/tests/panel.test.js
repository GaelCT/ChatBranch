import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
// Focused DOM fixture for the actual panel module; no browser rendering is asserted.
class Element{
  constructor(tag='div'){this.tag=tag;this.children=[];this.listeners={};this.dataset={};this.attributes={};this.value='';this.checked=false;this.disabled=false;this.hidden=false;this._text='';}
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
  append(...children){this.children.push(...children);}
  replaceChildren(...children){this._text='';this.children=children;}
  setAttribute(key,value){this.attributes[key]=value;}
  addEventListener(event,fn){(this.listeners[event]||=[]).push(fn);}
  async fire(event){for(const fn of this.listeners[event]||[])await fn({target:this});}
  focus(){}select(){}scrollIntoView(){}
}
test('panel permits public loading, resets carried branches, preserves manual branches and exposes load errors',async()=>{
  const html=await readFile(new URL('../extension/panel.html',import.meta.url),'utf8');
  const elements=new Map([...html.matchAll(/<([a-z][a-z0-9-]*)\b[^>]*\bid="([^"]+)"[^>]*>/g)].map(m=>{const e=new Element(m[1]);e.hidden=/\bhidden\b/.test(m[0]);e.checked=/\bchecked\b/.test(m[0]);e.disabled=/\bdisabled\b/.test(m[0]);return [m[2],e];}));
  const $=id=>elements.get(id);let clipboardText='',storageListener;
  const calls=[];let current={config:{},user:null,snapshot:null,review:null,pending:null,published:null,ci:null};
  const original={document:globalThis.document,chrome:globalThis.chrome,setInterval:globalThis.setInterval,navigator:Object.getOwnPropertyDescriptor(globalThis,'navigator')};
  globalThis.document={getElementById:$,createElement:tag=>new Element(tag)};
  globalThis.setInterval=()=>0;
  Object.defineProperty(globalThis,'navigator',{configurable:true,value:{clipboard:{async writeText(text){clipboardText=text;}}}});
  globalThis.chrome={runtime:{getURL:p=>'chrome-extension://fixture/'+p,async sendMessage(m){
    calls.push(m);
    if(m.type==='state'||m.type==='connection-check')return {ok:true,value:structuredClone(current)};
    if(m.type==='load'){
      if(m.repo==='owner/missing')return {ok:false,error:'Repository not found: owner/missing. Use a public repo URL.'};
      const branch=m.branch||(m.repo==='owner/two'?'master':'main');
      current={...current,snapshot:{fullName:m.repo,branch,sha:'a'.repeat(40),entries:[{path:'src/app.js',mode:'100644',type:'blob',size:10}],suggested:['src/app.js'],push:false},loadStatus:{phase:'loaded',message:'Loaded '+m.repo+' · '+branch}};
      storageListener?.({loadStatus:{newValue:current.loadStatus}},'session');return {ok:true,value:structuredClone(current)};
    }
    if(m.type==='context')return {ok:true,value:{text:'=== FILE: src/app.js ===\nexport const value = 1;\n=== END FILE ==='}};
    throw new Error('Unexpected message '+m.type);
  }},storage:{onChanged:{addListener:fn=>{storageListener=fn;}}},tabs:{async create(){}}};
  try{
    await import('../extension/panel.js');await new Promise(resolve=>setImmediate(resolve));
    assert.equal($('load').disabled,false);assert.equal($('copy-context').disabled,true);
    $('repo').value='owner/one';await $('repo').fire('input');await $('load').fire('click');
    assert.equal($('base').value,'main');assert.equal($('file-tree').children.length,1);assert.equal($('copy-context').disabled,false);assert.equal($('review').disabled,true);assert.equal($('publish').disabled,true);
    await $('copy-context').fire('click');assert.match(clipboardText,/export const value = 1/);assert.equal($('repo-title').textContent,'owner/one');
    $('repo').value='owner/two';await $('repo').fire('input');assert.equal($('base').value,'');assert.equal($('copy-context').disabled,true);
    await $('load').fire('click');assert.equal(calls.filter(c=>c.type==='load').at(-1).branch,'');assert.equal($('base').value,'master');assert.equal($('load').disabled,false);
    $('base').value='release';await $('base').fire('input');$('repo').value='owner/three';await $('repo').fire('input');assert.equal($('base').value,'release');await $('load').fire('click');assert.equal($('repo-meta').textContent,'release · aaaaaaa');
    $('repo').value='owner/missing';await $('repo').fire('input');await $('load').fire('click');assert.match($('load-status').textContent,/Repository not found/);assert.equal($('load-status').className,'warning');assert.equal($('load').disabled,false);assert.equal($('copy-context').disabled,true);
    current={...current,user:{login:'GaelCT',canPublish:true},connection:{state:'connected',login:'GaelCT',canPublish:true,workflow:false,checkedAt:Date.now(),apiReachable:true,access:{api:true,oauth:true},version:'0.2.0'}};
    await $('check-connection').fire('click');assert.match($('account-status').textContent,/Account: verified @GaelCT/);assert.match($('api-status').textContent,/reachable/);assert.equal($('allow-access').hidden,true);assert.match($('connection-version').textContent,/0.2.0/);
    current.config={workflow:true};await $('check-connection').fire('click');assert.equal($('signin').hidden,false);assert.equal($('signin').textContent,'Add workflow access');
    current={...current,user:null,connection:{...current.connection,state:'unreachable',remembered:true,apiReachable:false,message:'Failed to fetch'}};
    await $('check-connection').fire('click');assert(!$('account-status').textContent.includes('Account: verified'));assert.match($('account-status').textContent,/sign-in saved/);assert.equal($('connection-error').hidden,false);assert.equal($('signin').hidden,true);assert.equal($('publish').disabled,true);
    current={...current,connection:{...current.connection,state:'permission_required',access:{api:false,oauth:true},message:'Allow GitHub access',secret:'not-for-diagnostics'}};await $('check-connection').fire('click');assert.equal($('allow-access').hidden,false);assert.match($('api-status').textContent,/permission required/);
    await $('copy-diagnostics').fire('click');assert.equal(JSON.parse(clipboardText).version,'0.2.0');assert.equal(JSON.parse(clipboardText).api.permission,false);assert(!clipboardText.includes('not-for-diagnostics'));
  }finally{
    for(const key of ['document','chrome','setInterval'])original[key]===undefined?delete globalThis[key]:globalThis[key]=original[key];
    original.navigator?Object.defineProperty(globalThis,'navigator',original.navigator):delete globalThis.navigator;
  }
});
