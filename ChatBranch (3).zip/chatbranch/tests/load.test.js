import test from 'node:test';
import assert from 'node:assert/strict';
import {GitHub} from '../extension/core/github.js';
const sha='a'.repeat(40),tree='b'.repeat(40);
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json'}});
function fixture({branch='master',failStage='',failStatus=404,privateRepo=false,malformedTree=false}={}){
  const calls=[];const fetcher=async(url,options)=>{
    const path=new URL(url).pathname;calls.push({path,options});
    const stage=path.endsWith('/demo')?'repo':path.includes('/git/ref/')?'ref':path.includes('/git/commits/')?'commit':'tree';
    if(stage===failStage)return json({message:failStatus===409?'Git Repository is empty.':'Not Found'},failStatus);
    if(stage==='repo')return json({full_name:'owner/demo',name:'demo',private:privateRepo,default_branch:branch});
    if(stage==='ref')return json({object:{sha}});
    if(stage==='commit')return json({tree:{sha:tree}});
    return json(malformedTree?{}:{truncated:false,tree:[{path:'src/app.js',mode:'100644',type:'blob',sha:'blob',size:10}]});
  };return {api:new GitHub(null,fetcher),calls};
}
test('public repo loads without an Authorization header and uses its actual default branch',async()=>{
  const {api,calls}=fixture();const progress=[];
  const snapshot=await api.snapshot('owner/demo','',{onProgress:async message=>progress.push(message)});
  assert.equal(snapshot.branch,'master');assert.equal(snapshot.entries[0].path,'src/app.js');assert(calls[1].path.endsWith('/heads/master'));assert(calls.every(c=>!('Authorization' in c.options.headers)));assert.equal(progress.length,4);
});
test('missing repo and missing branch identify the problem and the next step',async()=>{
  await assert.rejects(fixture({failStage:'repo'}).api.snapshot('owner/demo'),/Repository not found: owner\/demo.*public repo URL/);
  await assert.rejects(fixture({failStage:'ref'}).api.snapshot('owner/demo','wrong'),/Branch "wrong".*Leave Base branch blank/);
});
test('empty and private repositories produce clear load errors',async()=>{
  await assert.rejects(fixture({failStage:'ref',failStatus:409}).api.snapshot('owner/demo'),/empty.*README/);
  await assert.rejects(fixture({privateRepo:true}).api.snapshot('owner/demo'),/public repositories only/);
});
test('commit/tree and network failures identify the failed load stage',async()=>{
  await assert.rejects(fixture({failStage:'commit'}).api.snapshot('owner/demo'),/selected commit/);
  await assert.rejects(fixture({failStage:'tree'}).api.snapshot('owner/demo'),/repository files/);
  await assert.rejects(fixture({malformedTree:true}).api.snapshot('owner/demo'),/unreadable repository file list/);
  await assert.rejects(new GitHub(null,async()=>{throw new TypeError('Failed to fetch');}).snapshot('owner/demo'),/Could not read owner\/demo.*Could not reach GitHub/);
});
test('repo reads continue with the canonical name returned after a rename',async()=>{
  const paths=[];const api=new GitHub(null,async url=>{const p=new URL(url).pathname;paths.push(p);if(p==='/repos/owner/old')return json({name:'new',full_name:'owner/new',default_branch:'main',private:false});if(p.endsWith('/heads/main'))return json({object:{sha}});if(p.includes('/git/commits/'))return json({tree:{sha:tree}});return json({tree:[],truncated:false});});
  const snapshot=await api.snapshot('owner/old');assert.equal(snapshot.fullName,'owner/new');assert(paths.slice(1).every(p=>p.startsWith('/repos/owner/new/')));
});
