// Optional real Chromium test. All GitHub requests use in-worker fixtures.
// Install playwright separately; no test requests can write to a real repo.
import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {mkdir} from 'node:fs/promises';
import {chromium} from 'playwright';
const extension=resolve(import.meta.dirname,'../extension');
const context=await chromium.launchPersistentContext('',{channel:'chromium',headless:true,...(process.env.CHATBRANCH_CHROME_BINARY?{executablePath:process.env.CHATBRANCH_CHROME_BINARY}:{}),args:['--no-sandbox','--disable-extensions-except='+extension,'--load-extension='+extension]});
try{
  const worker=context.serviceWorkers()[0]||await context.waitForEvent('serviceworker');
  const id=new URL(worker.url()).host;
  await worker.evaluate(()=>{
    const base='a'.repeat(40),next='b'.repeat(40),old='export const value = 1;\n';
    const refs=new Map([['main',base]]),trees=new Map([['base-tree',[{path:'src/hello.js',type:'blob',mode:'100644',sha:'base-blob',size:old.length}]]]);
    const blobs=new Map([['base-blob',old]]),commits=new Map([[base,{sha:base,tree:{sha:'base-tree'},parents:[]}]]);
    globalThis.fixtureCalls=[];
    globalThis.fetch=async(url,options={})=>{
      fixtureCalls.push({url,method:options.method||'GET',body:options.body?JSON.parse(options.headers?.['Content-Type']==='application/json'?options.body:'null'):null});
      const u=new URL(url),p=u.pathname,body=options.headers?.['Content-Type']==='application/json'?JSON.parse(options.body):null;
      const response=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json'}});
      if(p==='/login/device/code')return response({device_code:'fixture-device',user_code:'TEST-CODE',interval:5,expires_in:900});
      if(p==='/login/oauth/access_token')return response({access_token:'fixture-token',scope:'public_repo'});
      if(p==='/user')return response({login:'me'});
      if(p==='/repos/me/demo')return response({name:'demo',full_name:'me/demo',default_branch:'main',permissions:{push:true},private:false});
      if(p.startsWith('/repos/me/demo/git/ref/heads/')){const b=decodeURIComponent(p.slice('/repos/me/demo/git/ref/heads/'.length));return refs.has(b)?response({object:{sha:refs.get(b)}}):response({message:'missing'},404);}
      if(p.startsWith('/repos/me/demo/git/commits/'))return response(commits.get(p.split('/').at(-1)));
      if(p.startsWith('/repos/me/demo/git/trees/'))return response({truncated:false,tree:trees.get(p.split('/').at(-1))});
      if(p.startsWith('/repos/me/demo/git/blobs/')){const content=blobs.get(p.split('/').at(-1));return response({encoding:'base64',size:content.length,content:btoa(content)});}
      if(p==='/repos/me/demo/git/trees'&&body){const entries=structuredClone(trees.get(body.base_tree));for(const f of body.tree){const existing=entries.findIndex(e=>e.path===f.path);if(existing>=0)entries.splice(existing,1);if(f.sha!==null){const blob='blob-'+blobs.size;blobs.set(blob,f.content);entries.push({path:f.path,type:'blob',mode:f.mode,sha:blob,size:f.content.length});}}trees.set('changed-tree',entries);return response({sha:'changed-tree'});}
      if(p==='/repos/me/demo/git/commits'&&body){commits.set(next,{sha:next,tree:{sha:body.tree},parents:body.parents.map(sha=>({sha}))});return response({sha:next});}
      if(p==='/repos/me/demo/git/refs'&&body){refs.set(body.ref.replace('refs/heads/',''),body.sha);return response({});}
      if(p==='/repos/me/demo/pulls'&&options.method==='POST')return response({number:1,html_url:'https://github.com/me/demo/pull/1'});
      if(p==='/repos/me/demo/pulls')return response([]);
      if(p==='/repos/me/demo/pulls/1')return response({number:1,state:'open',merged:false,html_url:'https://github.com/me/demo/pull/1',head:{sha:next,ref:'chatbranch/browser-test',repo:{full_name:'me/demo'}},base:{ref:'main'}});
      if(p.endsWith('/check-runs'))return response({total_count:1,check_runs:[{id:1,name:'Unit tests',head_sha:next,status:'completed',conclusion:'success',html_url:'https://github.com/me/demo/actions/runs/1'}]});
      if(p.endsWith('/status'))return response({statuses:[]});
      if(p.endsWith('/actions/runs'))return response({workflow_runs:[]});
      throw new Error('Fixture has no route for '+p);
    };
  });
  const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.setViewportSize({width:1180,height:1000});await page.goto(`chrome-extension://${id}/panel.html`);
  await page.locator('#client-id').fill('Ov23_exampleclient');await page.locator('#save-config').click();await page.waitForFunction(()=>document.getElementById('notice').textContent.includes('Setup saved'));
  await page.locator('#signin').click();await page.locator('#device-code').waitFor();
  assert.equal(await page.locator('#device-code').textContent(),'TEST-CODE');
  await worker.evaluate(async()=>{const {device}=await chrome.storage.session.get('device');device.nextPoll=0;await chrome.storage.session.set({device});});
  await page.waitForFunction(()=>document.getElementById('identity').textContent.includes('Signed in as @me'),null,{timeout:15000});
  await page.locator('#check-connection').click();await page.waitForFunction(()=>document.getElementById('account-status').textContent.includes('Account: verified @me'));
  const initialOAuthCalls=await worker.evaluate(()=>fixtureCalls.filter(c=>c.url.includes('/login/')).length);
  await worker.evaluate(async()=>{await chrome.storage.session.clear();});
  await page.reload();await page.waitForFunction(()=>document.getElementById('account-status').textContent.includes('Account: verified @me'),null,{timeout:15000});
  assert.equal(await worker.evaluate(()=>fixtureCalls.filter(c=>c.url.includes('/login/')).length),initialOAuthCalls);
  assert.match(await page.locator('#api-status').textContent(),/reachable/);
  await page.locator('#repo').fill('me/demo');await page.locator('#load').click();await page.waitForFunction(()=>document.getElementById('repo-title').textContent==='me/demo');
  await page.locator('#file-tree input').check();await page.locator('#task').fill('Change value to 2 and add a test.');await page.locator('#copy-context').click();await page.waitForFunction(()=>document.getElementById('context-text').value.includes('export const value = 1'));
  assert.equal(await page.locator('#identity').textContent(),'Signed in as @me');
  const bundle={schemaVersion:1,baseCommit:'a'.repeat(40),summary:'Update value and test',files:[{path:'src/hello.js',content:'export const value = 2;\n'},{path:'test/hello.test.js',content:'// Example test fixture\n'}]};
  await page.locator('#response').fill(JSON.stringify(bundle));await page.locator('#review').click();await page.waitForFunction(()=>document.querySelectorAll('.diff').length===2);
  assert.match(await page.locator('#diffs').textContent(),/export const value = 2/);
  assert(await page.locator('#publish').isDisabled());
  await page.locator('#pr-title').fill('Update value and test');await page.locator('#branch').fill('chatbranch/browser-test');await page.locator('#ack').check();await page.locator('#publish').click();await page.waitForFunction(()=>document.getElementById('pr-link').href.endsWith('/pull/1'));
  await page.locator('#refresh-ci').click();await page.waitForFunction(()=>document.getElementById('ci-badge').textContent==='Checks passed');
  await page.locator('#fix-pr').click();await page.waitForFunction(()=>document.getElementById('publish-heading').textContent==='Update the pull request');
  assert.equal(await page.locator('#branch').inputValue(),'chatbranch/browser-test');assert(await page.locator('#branch').evaluate(n=>n.readOnly));
  await context.route('https://chatgpt.com/**',route=>route.fulfill({contentType:'text/html',body:'<!doctype html><div data-message-author-role="assistant"><div class="markdown"><h3>File: <code>src/hello.js</code></h3><pre><code class="language-javascript">export const value = 3;\n</code></pre></div></div>'}));
  const chat=await context.newPage();await chat.goto('https://chatgpt.com/c/fixture');await chat.getByRole('button',{name:'Send to ChatBranch'}).click();
  await page.waitForFunction(()=>document.getElementById('response').value.includes('export const value = 3;'));
  const captured=await worker.evaluate(async()=> (await chrome.storage.session.get('pending')).pending?.text);
  // The panel may already have consumed pending. In that case its textarea has it.
  const capturedText=captured||await page.locator('#response').inputValue();assert.match(capturedText,/File: `src\/hello.js`/);assert.match(capturedText,/```javascript/);
  const calls=await worker.evaluate(()=>fixtureCalls);
  assert(calls.some(c=>c.method==='POST'&&c.url.endsWith('/git/refs')&&c.body.ref==='refs/heads/chatbranch/browser-test'));
  assert(!calls.some(c=>c.method==='PATCH'));
  assert.equal(errors.length,0,errors.join('\n'));
  await mkdir(resolve('test-results'),{recursive:true});await page.screenshot({path:resolve('test-results/workspace.png'),fullPage:true});await page.setViewportSize({width:400,height:900});await page.screenshot({path:resolve('test-results/narrow.png'),fullPage:true});
  console.log('Chromium smoke passed: sign-in UI, context, diff, publish, checks, PR reload and capture. No live GitHub writes.');
}finally{await context.close();}
