import test from 'node:test';
import assert from 'node:assert/strict';
import {GitHub,summarizeChecks,readCI} from '../extension/core/github.js';
test('authenticated reads support repo redirects and writes reject redirects',async()=>{
  let call;const api=new GitHub('fake-token',async(url,options)=>{call={url,...options};return new Response('{}',{status:200});});await api.request('/user');assert.equal(call.url,'https://api.github.com/user');assert.equal(call.redirect,'follow');assert.equal(call.credentials,'omit');assert.equal(call.headers.Authorization,'Bearer fake-token');await api.request('/repos/a/b/git/trees',{method:'POST',body:{}});assert.equal(call.redirect,'error');await assert.rejects(api.request('//evil.test/user'),/Invalid/);
});
test('responses redirected outside the API host are rejected',async()=>{
  const response=new Response('{}');Object.defineProperty(response,'url',{value:'https://other.test/'});
  await assert.rejects(new GitHub('token',async()=>response).request('/user'),/outside api.github.com/);
});
test('transport diagnostics retain failure reason and redact the token',async()=>{
  const token='example-secret-token';const api=new GitHub(token,async()=>{throw new Error('Failed to fetch '+token);});
  await assert.rejects(api.request('/user'),e=>e.name==='GitHubNetworkError'&&e.message.includes('Failed to fetch')&&!e.message.includes(token)&&e.message.includes('Check connection'));
});
test('non-JSON proxy responses expose HTTP status without claiming GitHub replied',async()=>{
  const api=new GitHub(null,async()=>new Response('blocked by proxy',{status:403}));
  await assert.rejects(api.request('/rate_limit'),e=>e.status===403&&e.apiResponse===false&&e.message.includes('non-JSON'));
});
test('no checks and all-skipped checks are not labelled as passing tests',()=>{
  assert.equal(summarizeChecks([],[],[]).state,'none');assert.equal(summarizeChecks([{name:'test',status:'completed',conclusion:'skipped'}],[],[]).state,'skipped');assert.equal(summarizeChecks([{name:'test',status:'completed',conclusion:'success'}],[],[]).state,'passed');assert.equal(summarizeChecks([],[],[{name:'CI',status:'waiting'}]).state,'pending');
});
test('check results follow latest PR head and ignore stale commits and old reruns',async()=>{
  const head='a'.repeat(40),old='b'.repeat(40);const calls=[];
  const api={async request(p){calls.push(p);if(p.endsWith('/pulls/1'))return {number:1,state:'open',head:{sha:head,repo:{full_name:'up/project'}},html_url:'https://github.com/up/project/pull/1'};if(p.includes('/check-runs'))return {check_runs:[{id:1,name:'test',head_sha:old,status:'completed',conclusion:'failure'},{id:2,name:'test',head_sha:head,status:'completed',conclusion:'success'}]};if(p.includes('/status'))return {statuses:[]};return {workflow_runs:[{id:10,workflow_id:1,name:'CI',head_sha:head,event:'pull_request',created_at:'2026-10-01',status:'completed',conclusion:'failure'},{id:11,workflow_id:1,name:'CI',head_sha:head,event:'pull_request',created_at:'2026-10-02',status:'completed',conclusion:'success'}]};}};
  const ci=await readCI(api,{upstream:'up/project',number:1});assert.equal(ci.sha,head);assert.equal(ci.state,'passed');assert(!ci.items.some(c=>c.state==='failure'));assert(calls.every(c=>!c.includes(old)));
});
test('unreadable check endpoints do not claim complete success',async()=>{
  const head='a'.repeat(40);const api={async request(p){if(p.endsWith('/pulls/1'))return {number:1,head:{sha:head,repo:{full_name:'a/b'}},state:'open'};if(p.includes('/check-runs'))throw new Error('blocked');if(p.includes('/status'))return {statuses:[{context:'test',state:'success'}]};return {workflow_runs:[]};}};
  const result=await readCI(api,{upstream:'a/b',number:1});assert.equal(result.state,'incomplete');assert.equal(result.warnings.length,1);
});
test('stale test merge cannot supply a passing result for a newer head',async()=>{
  const head='a'.repeat(40),merge='c'.repeat(40);let mergeQueried=false;
  const api={async request(p){if(p.endsWith('/pulls/1'))return {head:{sha:head,repo:{full_name:'up/project'}},merge_commit_sha:merge,state:'open'};if(p.includes('/git/commits/'))return {parents:[{sha:'b'.repeat(40)}]};if(p.includes(merge))mergeQueried=true;if(p.includes('/check-runs'))return {check_runs:[]};if(p.includes('/status'))return {statuses:[]};return {workflow_runs:[]};}};
  const result=await readCI(api,{upstream:'up/project',number:1});assert.equal(mergeQueried,false);assert.equal(result.state,'none');assert.match(result.warnings[0],/caught up/);
});
