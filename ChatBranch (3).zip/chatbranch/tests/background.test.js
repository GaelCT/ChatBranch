import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const sha='a'.repeat(40),next='b'.repeat(40),baseURL='chrome-extension://test-extension/';
function storage(){const data={};return {data,async setAccessLevel(value){this.access=value.accessLevel;},async get(key){return structuredClone(key===null?data:Object.fromEntries((Array.isArray(key)?key:[key]).filter(k=>k in data).map(k=>[k,data[k]])));},async set(value){Object.assign(data,structuredClone(value));},async remove(key){for(const k of Array.isArray(key)?key:[key])delete data[k];},async clear(){for(const k of Object.keys(data))delete data[k];}};}
test('service worker completes sign-in → pinned context → review → PR; content scripts receive no credentials',async()=>{
  const local=storage(),session=storage();let listener,opened=0,created=false,apiPermission=true,failApi=false;const calls=[];
  globalThis.chrome={runtime:{id:'test-extension',getURL:path=>baseURL+path,getManifest:()=>({version:'0.2.0'}),onMessage:{addListener:fn=>{listener=fn;}}},permissions:{async contains({origins}){return origins[0].includes('api.github')?apiPermission:true;}},storage:{local,session},sidePanel:{async setPanelBehavior(){},async open(){opened++;}},alarms:{async create(){},async clear(){},onAlarm:{addListener(){}}}};
  const oldFetch=globalThis.fetch;
  globalThis.fetch=async(url,options={})=>{
    if(failApi&&url.startsWith('https://api.github.com'))throw new TypeError('Failed to fetch');
    calls.push({url,options});const p=new URL(url).pathname;let value,status=200;
    if(p==='/login/device/code')value={device_code:'hidden-device',user_code:'CODE-1234',interval:5,expires_in:900};
    else if(p==='/login/oauth/access_token')value={access_token:'hidden-token',scope:'public_repo workflow'};
    else if(p==='/user')value={login:'me'};
    else if(p==='/rate_limit')value={resources:{core:{remaining:50}}};
    else if(p==='/repos/me/demo')value={full_name:'me/demo',name:'demo',default_branch:'main',permissions:{push:true},private:false};
    else if(p==='/repos/me/demo/git/ref/heads/main')value={object:{sha}};
    else if(p==='/repos/me/demo/git/ref/heads/not-real'){status=404;value={message:'Not Found'};}
    else if(p==='/repos/me/demo/git/commits/'+sha)value={tree:{sha:'tree'}};
    else if(p==='/repos/me/demo/git/trees/tree')value={tree:[{path:'src/cart.js',type:'blob',mode:'100644',sha:'blob',size:12}]};
    else if(p==='/repos/me/demo/git/blobs/blob')value={encoding:'base64',size:12,content:btoa('old source\n')};
    else if(p.includes('/git/ref/heads/chatbranch')){status=created?200:404;value=created?{object:{sha:next}}:{message:'missing'};}
    else if(p.endsWith('/git/trees'))value={sha:'new-tree'};
    else if(p.endsWith('/git/commits'))value={sha:next};
    else if(p.endsWith('/git/refs')){created=true;value={};}
    else if(p.endsWith('/pulls') && options.method==='POST')value={number:1,html_url:'https://github.com/me/demo/pull/1'};
    else if(p.endsWith('/pulls'))value=[];
    else throw new Error('Unexpected request: '+p);
    return new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json'}});
  };
  await import('../extension/background.js');
  const panel={id:'test-extension',url:baseURL+'panel.html'};
  const message=(m,sender=panel)=>new Promise(resolve=>{const accepted=listener(m,sender,resolve);if(!accepted)resolve(undefined);});
  try{
    assert.equal(await message({type:'publish'}, {id:'test-extension',url:'https://chatgpt.com/',tab:{id:1}}),undefined);
    assert((await message({type:'configure',clientId:'Ov23_exampleclient',workflow:true})).ok);
    let r=await message({type:'signin'});assert.equal(r.value.device.userCode,'CODE-1234');assert(!JSON.stringify(r).includes('hidden-device'));
    session.data.device.nextPoll=0;r=await message({type:'state'});assert.equal(r.value.user.login,'me');assert.equal(local.data.githubAuth.token,'hidden-token');assert.equal(session.data.auth,undefined);assert(!JSON.stringify(r).includes('hidden-token'));assert.equal(local.access,'TRUSTED_CONTEXTS');assert.equal(r.value.connection.state,'connected');
    const oauthCalls=calls.filter(c=>c.url.includes('/login/')).length;
    await session.clear();await message({type:'state'});r=await message({type:'connection-check'});
    assert.equal(r.value.user.login,'me');assert.equal(calls.filter(c=>c.url.includes('/login/')).length,oauthCalls);assert(!JSON.stringify(r).includes('hidden-token'));
    failApi=true;r=await message({type:'load',repo:'me/demo'});assert(!r.ok);assert.match(r.error,/Failed to fetch/);assert.equal(local.data.githubAuth.token,'hidden-token');
    r=await message({type:'state'});assert.equal(r.value.connection.state,'unreachable');assert.equal(r.value.user,null);assert.equal(r.value.connection.remembered,true);
    failApi=false;r=await message({type:'connection-check'});assert.equal(r.value.user.login,'me');assert.equal(calls.filter(c=>c.url.includes('/login/')).length,oauthCalls);
    apiPermission=false;r=await message({type:'state'});assert.equal(r.value.connection.state,'permission_required');assert.equal(r.value.user,null);assert.equal(local.data.githubAuth.token,'hidden-token');
    apiPermission=true;r=await message({type:'connection-check'});assert.equal(r.value.user.login,'me');assert.equal(calls.filter(c=>c.url.includes('/login/')).length,oauthCalls);
    r=await message({type:'load',repo:'me/demo'});assert.equal(r.value.snapshot.sha,sha);
    r=await message({type:'context',paths:['src/cart.js'],task:'Fix it'});assert(r.ok);assert(r.value.text.includes('old source'));assert(r.value.text.includes(sha));
    const bundle={schemaVersion:1,baseCommit:sha,files:[{path:'src/cart.js',content:'new source\n'}]};
    assert.equal((await message({type:'review',text:JSON.stringify({...bundle,baseCommit:next})})).ok,false);
    const content={id:'test-extension',url:'https://chatgpt.com/c/example',tab:{id:9}};
    r=await message({type:'capture',text:JSON.stringify(bundle)},content);assert.deepEqual(r,{ok:true});assert.equal(opened,1);assert.equal(session.data.pending.text,JSON.stringify(bundle));assert(!created);
    r=await message({type:'review',text:JSON.stringify(bundle)});assert(r.ok,r.error);assert.equal(r.value.review.files[0].before,'old source\n');
    const id=r.value.review.id;
    assert.equal((await message({type:'publish',reviewId:'wrong'})).ok,false);
    r=await message({type:'publish',reviewId:id,branch:'main',title:'Fix',message:'Fix'});assert(!r.ok);assert.equal(session.data.publishOptions,undefined);
    r=await message({type:'publish',reviewId:id,branch:'chatbranch/fix',title:'Fix',message:'Fix',draft:true});assert(r.ok,r.error);assert.equal(r.value.published.number,1);assert.equal(r.value.review,null);
    const writes=calls.filter(c=>['POST','PATCH'].includes(c.options.method)&&c.url.startsWith('https://api.github.com'));
    assert(writes.every(c=>c.options.headers.Authorization==='Bearer hidden-token'));
    r=await message({type:'logout'});assert(r.ok);assert.equal(Object.keys(session.data).length,0);
    assert.equal(local.data.githubAuth,undefined);
    const beforeRead=calls.length;
    r=await message({type:'load',repo:'me/demo'});assert(r.ok,r.error);assert.equal(r.value.user,null);assert.equal(r.value.snapshot.sha,sha);assert.equal(r.value.loadStatus.phase,'loaded');
    r=await message({type:'context',paths:['src/cart.js'],task:'Inspect this public source'});assert(r.ok,r.error);assert(r.value.text.includes('old source'));
    assert(calls.slice(beforeRead).every(c=>!c.options.headers.Authorization&&c.options.method==='GET'));
    assert.equal((await message({type:'review',text:JSON.stringify(bundle)})).ok,false);
    assert.equal((await message({type:'publish',reviewId:id,branch:'chatbranch/anon'})).ok,false);
    r=await message({type:'load',repo:'me/demo',branch:'not-real'});assert(!r.ok);assert.match(r.error,/Branch "not-real".*not found/);assert.equal(session.data.loadStatus.phase,'error');
    r=await message({type:'connection-check'});assert(r.ok);assert.equal(r.value.connection.apiReachable,true);assert.equal(r.value.user,null);
    apiPermission=false;r=await message({type:'load',repo:'me/demo'});assert(!r.ok);assert.match(r.error,/Allow GitHub access/);
    r=await message({type:'state'});assert.equal(r.value.connection.state,'permission_required');
    // A school page cannot initiate arbitrary authenticated API requests.
    assert.equal(await message({type:'load',repo:'me/demo'},content),undefined);
  }finally{globalThis.fetch=oldFetch;delete globalThis.chrome;}
});
