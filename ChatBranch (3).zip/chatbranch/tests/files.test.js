import test from 'node:test';
import assert from 'node:assert/strict';
import {repoName,safePath,safeBranch,parseImport,applyPatch,validateChanges,diffLines} from '../extension/core/files.js';
const sha='a'.repeat(40);
test('only explicit GitHub public repo names are accepted',()=>{
  assert.equal(repoName('https://github.com/acme/widgets.git'),'acme/widgets');
  for(const input of ['https://evil.test/acme/widgets','https://github.com@evil.test/a/b','https://github.com/acme/widgets/tree/main','../repo','https://github.com:123/a/b'])assert.throws(()=>repoName(input));
});
test('block traversal, secrets, metadata and invalid branch names',()=>{
  for(const p of ['../x','/x','a/../x','a\\b','.git/config','.env','.env.production','keys/private.pem','a//b','C:/x','a\0b'])assert.throws(()=>safePath(p));
  assert.equal(safePath('.github/workflows/ci.yml'),'.github/workflows/ci.yml');
  for(const b of ['main..x','x.lock','x/','x@{1}','.hidden','x y','x//y'])assert.throws(()=>safeBranch(b));
  assert.equal(safeBranch('chatbranch/fix-cart'),'chatbranch/fix-cart');
});
test('JSON bundle preserves literal newlines and deletion',()=>{
  const bundle={schemaVersion:1,baseCommit:sha,summary:'Fix validation',files:[{path:'src/a.js',content:'export const x = 1;\n'},{path:'old.js',action:'delete'}]};
  const parsed=parseImport('Here is the change:\n```json\n'+JSON.stringify(bundle)+'\n```\n');
  assert.equal(parsed.baseCommit,sha);assert.equal(parsed.files[0].content,'export const x = 1;\n');assert.equal(parsed.files[1].action,'delete');
});
test('complete markdown files need explicit paths; language labels never become paths',()=>{
  assert.equal(parseImport('### File: `src/a.js`\n```javascript\nlet x = 1;\n```\n').files[0].path,'src/a.js');
  assert.throws(()=>parseImport('```javascript\nlet x = 1;\n```'));
  assert.equal(parseImport('```javascript\nlet x = 1;\n```','src/a.js').files[0].content,'let x = 1;\n');
  assert.throws(()=>parseImport('### File: `src/a.js`\n```js\nx\n```\n```sh\nrm -rf /\n```'));
  assert.throws(()=>validateChanges([{path:'A.js',content:'a'},{path:'a.js',content:'b'}]));
});
test('exact unified diff updates, creates and deletes files',()=>{
  const patch='diff --git a/a.js b/a.js\n--- a/a.js\n+++ b/a.js\n@@ -1,2 +1,2 @@\n one\n-two\n+three\ndiff --git a/new.js b/new.js\n--- /dev/null\n+++ b/new.js\n@@ -0,0 +1 @@\n+new\ndiff --git a/old.js b/old.js\n--- a/old.js\n+++ /dev/null\n@@ -1 +0,0 @@\n-old\n';
  const files=applyPatch(patch,new Map([['a.js','one\ntwo\n'],['new.js',null],['old.js','old\n']]));
  assert.equal(files[0].content,'one\nthree\n');assert.equal(files[1].content,'new\n');assert.equal(files[2].action,'delete');
  assert.throws(()=>applyPatch(patch,new Map([['a.js','one\nchanged\n'],['new.js',null],['old.js','old\n']])),/context differs/);
});
test('patch verifies positions, count, file existence and no-newline markers',()=>{
  const p='--- a/x\n+++ b/x\n@@ -1 +1 @@\n-old\n\\ No newline at end of file\n+new\n\\ No newline at end of file\n';
  assert.equal(applyPatch(p,new Map([['x','old']]))[0].content,'new');
  assert.throws(()=>applyPatch(p,new Map([['x',null]])),/existence/);
  assert.throws(()=>applyPatch(p.replace('+1 @@','+3 @@'),new Map([['x','old']])),/position/);
  assert.throws(()=>applyPatch(p.replace('-1 +1','-1,2 +1'),new Map([['x','old']])),/counts|hunk/);
  assert.throws(()=>applyPatch('GIT binary patch\n'+p,new Map([['x','old']])),/Binary/);
});
test('diff represents changes and bounds work for large files',()=>{
  const diff=diffLines('a\nb\n','a\nc\n');
  assert(diff.some(x=>x.kind==='remove'&&x.text==='b'));assert(diff.some(x=>x.kind==='add'&&x.text==='c'));
  const large=Array.from({length:1000},(_,i)=>String(i)).join('\n');assert(diffLines(large,large+'\nend').some(x=>x.kind==='add'&&x.text==='end'));
});
test('fenced patch extraction excludes prose and preserves significant spaces',()=>{
  const patch='--- a/x\n+++ b/x\n@@ -1 +1 @@\n-old\n+new  \n';
  const fenced=parseImport('Here is the patch:\n```diff\n'+patch+'```\n');
  assert.equal(applyPatch(fenced.patch,new Map([['x','old\n']]))[0].content,'new  \n');
  assert.equal(applyPatch(parseImport(patch).patch,new Map([['x','old\n']]))[0].content,'new  \n');
});
