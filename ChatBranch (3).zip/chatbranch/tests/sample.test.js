import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,readFile,writeFile,rm,mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve,dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
test('sample regression tests expose the original bug and pass with the complete fix',async()=>{
  const temp=await mkdtemp(join(tmpdir(),'chatbranch-sample-'));
  try{
    await cp(resolve(import.meta.dirname,'../sample'),temp,{recursive:true});
    const bundle=JSON.parse(await readFile(resolve(import.meta.dirname,'../examples/cart-fix.json'),'utf8'));
    const regression=bundle.files.find(f=>f.path.startsWith('test/'));
    await writeFile(join(temp,regression.path),regression.content);
    const childEnv={...process.env};delete childEnv.NODE_TEST_CONTEXT;
    const run=()=>spawnSync(process.execPath,['--test','test/cart.test.js','test/cart-regression.test.js'],{cwd:temp,encoding:'utf8',env:childEnv});
    const before=run();assert.notEqual(before.status,0);assert.match(before.stdout,/negative prices/);assert.match(before.stdout,/overflow/);
    for(const f of bundle.files){await mkdir(dirname(join(temp,f.path)),{recursive:true});await writeFile(join(temp,f.path),f.content);}
    const after=run();assert.equal(after.status,0,after.stdout+after.stderr);assert.match(after.stdout,/(?:pass 8|8.*pass)/);
  }finally{await rm(temp,{recursive:true,force:true});}
});
