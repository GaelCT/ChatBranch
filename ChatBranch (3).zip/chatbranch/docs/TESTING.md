# Test report and acceptance checklist

## Verified in the build environment

- `npm test`: **44 passing tests**, including the real service-worker message handler with mocked Chrome storage and GitHub HTTP responses, plus a focused DOM fixture running the actual panel module.
- `npm run check`: manifest files, eight extension JavaScript files and 69 panel element IDs verified.
- Sample `npm test`: original three tests pass.
- Sample `npm run build`: valid `dist/cart.js` and its ESM package manifest produced.
- The sample's five additional regression tests fail against its original bug and pass after applying `examples/cart-fix.json` (eight sample tests in total after the fix).
- Sample workflow YAML parsed; push/PR triggers and read-only token permissions verified.

Tests cover explicit file imports and destinations, literal newline preservation, forbidden paths and secrets, duplicate imports, exact patch application, mismatched hunk counts and positions, no-final-newline markers, stale bundle/base commits, OAuth interval/slowdown/expiry/denial, credential isolation, one-commit code/test publishing, base-tree preservation, forks and unrelated repo-name collisions, interrupted writes, PR retries, and fast-forward PR updates.

CI tests distinguish no checks from success, reject stale commit results and stale PR test merges, select the latest workflow rerun, and mark unreadable results incomplete.

Version 0.1.1 regression checks also load a public repo and copy its context while signed out, verify those requests send no Authorization header, confirm review/publishing still require sign-in, resolve the actual repo default branch, diagnose missing repos/branches and empty repos, and report commit/tree/network failures. The panel fixture verifies the unsigned Load button is enabled, a carried-over base branch clears when switching repos, an explicitly entered branch remains intentional, changed inputs block use of the old snapshot, and load errors remain visible with retry enabled. This fixture does not validate actual Chrome rendering or extension API behavior.

Version 0.2.0 tests restore a private local credential after clearing session storage and re-instantiating the auth manager, verify it using `/user` without another device OAuth exchange, cache/expire a verification, coalesce concurrent checks, preserve credentials offline, remove revoked/expired credentials, obey current OAuth scopes, migrate the old session credential, and reject a late verification after logout. The integrated worker test reproduces a `Failed to fetch` repo load, confirms saved sign-in survives, then restores network/site access and reconnects without another device-code exchange. It verifies that public API reachability alone does not produce an authenticated user.

Panel checks cover verified/checking/offline/permission states, workflow-scope upgrade controls and whitelisted token-free diagnostics. Transport checks cover read redirects, write redirect rejection, unexpected final origins, canonical repository names, redacted failure reasons and non-JSON HTTP proxy errors.

## Not validated here

Chrome was not installed in the build environment, and the browser download was denied by its network policy. Therefore no real Chromium rendering/content-script/side-panel test was executed. Live OAuth registration, live GitHub writes, organization OAuth approvals, fork propagation and GitHub-hosted Actions were also not executed. The automatic tests exercise those API paths with fixtures; they do not prove production authorization or browser compatibility.

The optional `tests/browser-smoke.mjs` is provided for a Chromium session. It loads the actual unpacked extension, uses fake GitHub responses in the service worker, tests the workspace UI and synthetic ChatGPT capture, clears session storage/reloads the workspace to check remembered sign-in, and records wide/narrow screenshots. No live GitHub API requests occur in that test. It is supplied but was **not run** in this environment.

To run it in an environment with browser-download access:

```sh
npm install --no-save playwright@1.62.1
npx playwright install chromium
npm run test:browser
```

Alternatively set `CHATBRANCH_CHROME_BINARY` to a compatible Chromium binary supporting extension loading. Browser screenshots go to `test-results/` and are not part of the distributed extension.

## Live acceptance on your own demo repo

1. Load `extension/` unpacked in Chrome. Check its extension details page for service-worker errors. Open both the side panel and expanded tab; confirm they fit and controls are readable.
2. Before signing in, load a public repo with Base branch blank, select files and copy their context. Confirm review/publishing remain disabled. Then register an OAuth app, enable Device Flow, save its client ID and sign in. Confirm the correct GitHub username. Reload the repo. Sign out, verify the session clears, and sign in again.
   Confirm **Account: verified @yourname** and **API: reachable**. Close/reopen the workspace and restart Chrome; check that saved sign-in is verified quietly without another device code. Use Sign out to remove it, then verify a new sign-in is required. To diagnose a failure, use Check connection, Allow GitHub access when offered, Open API test and Copy diagnostics. A network failure must retain the saved token while withholding verified status.
3. Upload the sample folder contents to a public demo repo you own. Confirm its original CI passes. Load the repo in ChatBranch and select source/tests/instructions. Copy the prompt and check it contains the exact SHA and complete selected files.
4. Paste `examples/cart-fix.json`. Review the source diff and new regression test, create a draft PR on a fresh branch, and confirm unrelated files are still present on GitHub. Confirm the default branch was not changed.
5. Refresh CI. Confirm the current commit is shown and its tests/build pass. Open the Actions run and read its logs. Merge only if you choose, using GitHub. After a default-branch push succeeds, confirm the `cart-bundle` artifact is downloadable.
6. Reload ChatGPT and try **Send to ChatBranch** with a JSON response and explicit file-heading code blocks. Confirm capture alone creates no branch or PR. Confirm manual paste and text-file upload also work.
7. Deliberately make a test fail on a new demo PR. Open its failure log, copy summaries, load the PR branch, obtain a corrected bundle with fresh context, review and publish. Confirm this adds a commit to the same PR and does not force push.
8. On a public test repo owned by another account, contribute through a fork. Confirm the new branch belongs to your account and the PR targets the intended upstream/base. Use a repo/account where you are comfortable opening a test PR. Fork checks can need maintainer approval.
9. Move the base branch after a review and before publishing. Confirm the extension stops and asks for fresh context. Try a branch-name collision and confirm a new name can be chosen before any commit is created.
10. If adding a workflow, first verify the missing-scope error without the workflow checkbox. Enable it, save, sign in again, reload/review, and confirm the workflow write is authorized. A fork PR's workflow execution remains subject to upstream rules.

For real open-source contributions, follow the repository's `CONTRIBUTING` instructions, use meaningful tests for the requested behavior, and review the diff before submitting the PR.
