# Architecture

ChatBranch is a Manifest V3 extension with a module service worker and a shared side-panel/full-tab workspace. There is no application server and no AI API client.

| Module | Responsibility |
| --- | --- |
| `capture.js` | Add user-clicked capture buttons to assistant responses on chatgpt.com and reconstruct rendered code fences. |
| `panel.html`, `panel.js`, `theme.css` | Repo and file selection, copied context, imports, diff acknowledgement, explicit publishing, CI results. |
| `background.js` | Restrict trusted operations to the extension workspace, hold session credentials and immutable reviews, coordinate OAuth/publishing. |
| `core/oauth.js` | GitHub device flow and interval/expiry/slowdown handling. |
| `core/auth.js` | Trusted local credential storage, automatic identity/scope verification, cached status, session migration, logout/revocation handling. |
| `core/github.js` | Fixed-origin GitHub requests, immutable commit/tree/blob reads, check aggregation. |
| `core/files.js` | Text limits, path/branch validation, bundle/Markdown parsing, exact patch application, bounded diff generation. |
| `core/publish.js` | Fork discovery, atomic tree/commit creation, branch writes, PR creation, checkpoint recovery. |

The worker accepts only capture messages from the ChatGPT content script. All other operations require the packaged extension workspace. Access tokens never enter the panel's application state or content-script messages.

`AuthManager` protects local/session storage with `setAccessLevel(TRUSTED_CONTEXTS)` before migrating an older session credential or writing a new one. The credential lives in local storage under a random credential ID. The session holds a verification record bound to that ID; it is recomputed against GitHub `/user` after a restart. Identity responses and `X-OAuth-Scopes` determine the account label and publishing/workflow controls. A failed network check preserves the token and suspends verified status; HTTP 401 or expiry clears the unusable credential. Concurrent checks share one request, and a revision guard prevents a late check from restoring credentials after logout. No app client secret or remote token store is involved.

Host permissions are checked before operations. The panel can request only the two declared GitHub hosts directly from its user's click. API reachability and verified account state are displayed separately. Read requests allow normal HTTP redirects and verify the final API origin; Fetch strips Authorization across origins. Write requests reject redirects. Transport failures preserve a redacted cause and distinguish unreadable/non-JSON proxy responses. Snapshot reads preserve the cause chain so a failed repo request can update network status without forgetting the account.

Public repo loading and context reads can use an unsigned API client before OAuth setup. That client omits the Authorization header. Review, PR/branch writes and CI inspection still require the authenticated session. OAuth sign-in clears previous review/snapshot state, so the repo is reloaded with the user's current permissions before publishing.

Repo loading reads metadata, a branch ref, a Git commit and its recursive tree. Context and review read blobs by SHA, not a moving branch path. Review binds complete changes, original contents and the repo snapshot to a random review ID. Publishing takes that ID rather than accepting mutable file contents from the UI.

For a new contribution, the worker checks the loaded base ref, selects a writable repo/fork, creates one tree with `base_tree` and one commit with the reviewed base as parent, creates a new branch, then opens a PR against the selected upstream/base. Unrelated files are preserved and executable modes are retained. A changed base or branch conflict stops the operation. A failed PR step retains a branch checkpoint and comparison URL. Retry first looks for the exact authored commit to recover a ref-write response lost in transit.

For a PR fix, the worker reloads the head repo and branch, verifies push permission, and repeats review against its latest commit. Publishing rechecks that head and advances the ref with `force: false`. GitHub enforces the final fast-forward check if another writer races the update.

CI refresh reads the current PR head. Its test merge is considered only if the merge commit has that head as a parent. Results from unrelated previous commits are discarded. No results, all skipped, waiting, failures and successful available checks have different states. More than 100 results or missing check endpoints are disclosed as incomplete. Full job logs stay on GitHub; summaries and links can be copied to ChatGPT.

Use `public_repo` for the implemented write operations and optional `workflow` for workflow-file changes. This OAuth app scope model is broader than per-repository GitHub App installations; a future product version could introduce a GitHub App/backend for narrower installations. Other future work includes private repos, very large trees, binary files, an OS credential-store integration and live CI log downloads.
