# GitHub sign-in setup

Register a **GitHub OAuth app**, not a GitHub App. ChatBranch's first version uses OAuth scopes and the device authorization flow.

1. Open [GitHub → Settings → Developer settings → OAuth Apps → New OAuth App](https://github.com/settings/applications/new).
2. Application name: **ChatBranch**. Homepage URL: **`https://github.com`**. Authorization callback URL: **`https://github.com`**. The registration form requires a callback URL; the device flow does not use it.
3. Register the application. On its settings page, enable **Device Flow**. If the option is in the editing screen, select **Edit**, enable it, and save.
4. Copy the **Client ID**. Do not generate a client secret for this extension and do not paste any secret into it.
5. In the ChatBranch workspace, open **GitHub setup**, paste the client ID, choose whether to allow workflow changes, and **Save setup**.
6. Click **Sign in**. ChatBranch displays a short user code. Click **Continue on GitHub**, enter that code, and authorize your app. Verify that the account is the account you want to use.
7. Keep ChatBranch open while completing authorization. It polls at GitHub's allowed interval. The workspace shows your GitHub login after authorization. Load the repo after signing in.

No backend, client secret or model API key is needed. This registration is specific to your local installation; distributing a public product would normally use an app registration maintained by that product's owner.

The default OAuth scope is `public_repo`. It grants public-repo write operations needed for branches, commits, forks and PRs. To add or modify Actions workflow files, enable the checkbox, save, and sign in again to request `public_repo workflow`. Signing in again clears the current repo review; reload it and review afresh. Normal source/test edits do not require the workflow scope.

Version 0.2.0 remembers the access token in this Chrome profile's local extension storage, restricted to trusted extension contexts. It checks your saved account with GitHub automatically, caches a successful verification for up to five minutes, and repeats the check after an extension reload/browser restart. A temporary network failure retains the credential. **Sign out** removes it from Chrome but does not revoke the OAuth authorization on GitHub. You can revoke the grant under [Authorized OAuth Apps](https://github.com/settings/applications).

Look for **Account: verified @yourname**, its check time, and **API: reachable** in the workspace. **Check connection** forces a fresh check. Chrome site access is separate from GitHub OAuth authorization; **Allow GitHub access** restores withheld site permissions. **Open API test** checks whether the API opens in a normal browser tab, and **Copy diagnostics** produces a report with connection state and the error while excluding tokens/source contents. Adding workflow scope while connected exposes an **Add workflow access** button.

## Troubleshooting

| Symptom | Action |
| --- | --- |
| Device flow disabled | Edit the OAuth app and enable Device Flow. |
| Incorrect client credentials | Confirm you copied the OAuth app's client ID, not a secret or a GitHub App ID. |
| Code expired | Click Sign in for a new code. |
| Workflow scope missing | Save the workflow checkbox, sign in again, reload and review. |
| GitHub rejects a write | Check repo permissions, organization OAuth policies/SSO approval, branch rules and GitHub's error message. |
| Saved sign-in + API failure | Keep the saved credential. Check Chrome site access and the API test tab, then retry Check connection. |
| Account verified + publishing disabled | Check whether public_repo access is missing and choose Grant repo access. |
| Fork is preparing | Wait briefly and retry. It can take time for GitHub to make the selected commit available. |
| Branch already exists | Choose a new branch and retry, or load your published PR branch using the fix action. |

Official references: [device OAuth flow](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/authorizing-oauth-apps#device-flow), [OAuth scopes](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps), [Chrome extension network requests](https://developer.chrome.com/docs/extensions/develop/concepts/network-requests), [Chrome storage](https://developer.chrome.com/docs/extensions/reference/api/storage), [Chrome permissions](https://developer.chrome.com/docs/extensions/reference/api/permissions), [token revocation/expiry](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/token-expiration-and-revocation).
