# ChatBranch

A Chrome extension that turns code from your web ChatGPT conversations into reviewed GitHub pull requests. It uses the GitHub API directly. No model API subscription, client secret, server, or build step is required to run the extension.

Version 0.2.0 supports public GitHub.com repositories, including contributions through forks. It is a development build to load unpacked, not a Chrome Web Store release.

## Install in Chrome

1. Extract the ZIP. Keep the extracted folder; Chrome loads files from it.
2. Open `chrome://extensions`, switch on **Developer mode**, and choose **Load unpacked**.
3. Select **`chatbranch/extension`**, the folder containing `manifest.json`. Do not select the ZIP or the outer project folder.
4. Pin ChatBranch in Chrome's extensions menu and click its icon. The workspace opens in the side panel. Choose **Expand** for a larger tab.
5. Public repo loading and copying file context work before sign-in. To review changes and publish, follow [the OAuth setup guide](docs/OAUTH_SETUP.md), then sign in. You register your own GitHub OAuth app once and enter its public client ID. No client secret is used.
6. Reload an existing `chatgpt.com` tab to enable the **Send to ChatBranch** buttons. Manual paste and file imports also work.

Chrome 120 or newer is required. Node.js is only needed to run the project's tests, not to use the extension.

## Update an existing installation

Extract the updated ZIP and replace the files inside the **same extension folder you originally loaded**. Open `chrome://extensions`, find ChatBranch, and click **Reload**. Close the old workspace tab/panel and reopen it. Keeping the same folder path preserves the extension ID and its saved OAuth client ID; signing in may be needed again after reloading.

Version 0.2.0 remembers GitHub sign-in across reloads and browser restarts, verifies the account automatically, and shows API and account status separately. It also reports Chrome site-access problems and the underlying network failure, supports normal read redirects after repository renames, and offers a token-free diagnostic report. Leave **Base branch** blank to use the selected repo's own default branch. See [CHANGELOG.md](CHANGELOG.md).

After updating from 0.1.x, you may need to sign in once if the old temporary session has already been cleared. Keep the extension in the original folder so Chrome retains its extension ID and saved settings. New sign-ins are then remembered on this Chrome profile.

## Know whether GitHub is connected

The workspace shows **API** and **Account** separately. **Account: verified @yourname** means the extension received a successful authenticated `/user` response from GitHub. Its timestamp shows when that check succeeded; checks are cached for up to five minutes while the extension is open and repeated automatically when needed. The current OAuth scopes determine whether publishing/workflow access is shown as enabled.

Closing and reopening the workspace reuses the saved credential. After restarting Chrome or reloading the extension, the workspace quietly validates it again without requesting another device code. A temporary connection failure keeps the saved credential. An expired/revoked token or signing out requires a new sign-in; requesting additional scopes can also require authorization.

| What you see | Next step |
| --- | --- |
| API reachable + Account verified | Load your repo and continue. |
| API reachable + Account signed out | Sign in once to review and publish. Public context browsing works already. |
| Chrome permission required | Click **Allow GitHub access** and approve access to the two GitHub sites. |
| API connection failed + sign-in saved | Use **Open API test**. Keep the saved sign-in while diagnosing connectivity. |
| Account asks you to sign in again | GitHub rejected the token or it expired; authorize again. |
| Workflow access missing | Enable the workflow checkbox, save, then choose **Add workflow access**. Reload/review after authorization. |

**Check connection** runs a check immediately. **Copy diagnostics** copies version, permissions, verification state/times, repo/branch and the current error; it excludes tokens and source-file contents. **Open API test** opens GitHub's public rate-limit endpoint in a tab. If that tab also fails, the browser/network cannot reach the API. If it works while the extension fails, check the extension's GitHub site access and Chrome service-worker error in `chrome://extensions`.

## Use it

1. Enter a public GitHub repo URL or `owner/repo`. Choose a base branch if it differs from the repo default, then **Load repo**.
2. Select relevant source files, existing tests, `README`, `AGENTS.md` and contributor instructions. Describe the requested behavior, then **Copy prompt + files**. Paste that prompt into ChatGPT.
3. Use **Send to ChatBranch** on its response, or paste the response into the extension. Alternatively upload complete text files and confirm each destination path. Folder imports remove the selected top-level folder name. Select only the files you intend to change; secret files and large folders are rejected.
4. Click **Review changes**. Read every path, addition and deletion. The source commit is pinned; a bundle from a different commit is rejected. Do not treat a partial snippet as a complete replacement file.
5. Enter a PR title, new branch, commit message and description. Check the review acknowledgement, then **Publish branch + pull request**. Draft PR is the default. If you lack push access, ChatBranch creates or reuses your fork and opens the PR against the selected repo.
6. **Refresh checks** shows GitHub Actions, check runs and commit statuses attached to the PR's current head and verified test merge. Open GitHub for full logs. **Copy results for ChatGPT** copies summaries and links, not full job logs.
7. To fix a failed test, click **Load PR branch to fix**, select fresh files, copy context again, import a fix, review, and commit to the same PR branch. No force push or automatic merge is performed.

If you browsed before signing in, sign in before step 4 and reload the repository. Sign-in starts a fresh review session. Repository/branch errors now appear immediately below **Load repo**. An empty repo needs an initial commit before its files can be loaded. Changing repo or branch inputs disables context/review/publishing until you successfully load that selection.

The extension does not run generated code in Chrome or submit prompts to ChatGPT automatically. You control the conversation and publishing. It does not change your ChatGPT plan or its message limits.

## First demo

The [sample](sample/README.md) is a tiny JavaScript cart library with tests, an intentionally documented bug, and a GitHub Actions workflow. Upload the **sample folder's contents** to the root of a public repo you own. Load that repo in ChatBranch.

Ask ChatGPT to reject negative/unsafe prices and quantities and totals that overflow the safe integer range, and add regression tests while keeping zero valid. For a known correction, paste the contents of [examples/cart-fix.json](examples/cart-fix.json) into the extension and review it against the sample. The fixture intentionally omits `baseCommit` because your repo's initial SHA will differ.

The sample pipeline runs tests and builds a runnable ESM bundle. Successful pushes to its default branch deliver a `cart-bundle` artifact for download. This implements CI and delivery of a tested build. Deployment to a hosting provider is a separate project-specific step.

## Supported import formats

The recommended format is a single JSON bundle:

```json
{
  "schemaVersion": 1,
  "baseCommit": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  "summary": "Fix the requested behavior and add tests",
  "files": [
    {"path": "src/example.js", "action": "write", "content": "export const value = 1;\n"},
    {"path": "obsolete.js", "action": "delete"}
  ]
}
```

Use the real `baseCommit` from **Copy prompt + files**. Writes contain the whole file, not a snippet, diff, placeholder or shell command. JSON escapes such as `\n` decode to actual newlines. Deletions omit `content`.

Also supported: ordinary unified text diffs with exact context; Markdown code blocks preceded by an explicit heading such as **File: `src/example.js`**; and one complete unlabelled file when you enter its destination. Binary/rename-only patches are unsupported; represent a text rename as an explicit delete and write. Patch hunks must match exactly; no fuzzy application occurs.

Limits: 50 changed files, 512 KiB per UTF-8 text file, 3 MiB per import or context, 25 selected context files, and non-truncated repo trees up to 15,000 entries / 1.5 MB metadata. Chrome's session storage budget can further limit large reviews; split them into smaller contributions if asked. Long diff previews are capped at 2,000 lines, with the complete original/proposed files available underneath. Symlinks, submodules, Git metadata and common secret paths cannot be edited. Private repos and GitHub Enterprise hosts are not supported.

## Permissions and credentials

GitHub device OAuth requests `public_repo`, plus optional `workflow` for changing `.github/workflows/`. These OAuth scopes grant account-wide public repo permissions rather than a single selected repo; the workspace lets you choose the destination. `workflow` does not create deployment secrets or administer branch protection.

The client ID and remembered OAuth credential are kept in `chrome.storage.local`. Local and session storage access is explicitly restricted to `TRUSTED_CONTEXTS` before credentials are read or written. Chrome local storage persists on this profile; it is not an encrypted OS credential vault. Device codes, repo snapshots, reviews, connection-check cache and partial-publish checkpoints remain in `chrome.storage.session`. These temporary items clear on an extension reload or browser restart, while the saved sign-in remains. Tokens do not enter the panel's application state or copied prompts. Signing out removes the saved credential; revoke the OAuth grant in GitHub settings if you also want server-side revocation.

The content script only sends the assistant response you explicitly click. It cannot request authenticated repo reads or writes. Publishing requires a trusted extension page and a previously prepared, immutable review. ChatBranch only sends network requests to GitHub's API and OAuth endpoints.

## Checks and limitations

No checks is different from passed checks. Skipped/neutral checks do not count as passing tests. API-read failures or more than 100 results are marked incomplete instead of presenting a complete success. Existing workflow and third-party check behavior remain controlled by the repo. Fork CI can wait for maintainer approval. A newly added workflow may not run for a fork PR until the repository's own workflow rules allow it.

Only changed files enter a single commit; a base tree preserves the rest. A moved base branch requires a fresh review. Updates to an existing PR branch are fast-forward only. An interrupted publish can leave a branch or orphan Git objects. If the branch exists, the workspace provides a comparison link and retries the PR step without duplicating the commit. Checkpoints last for the current browser session; after a browser restart use GitHub's comparison page or choose a new branch. An existing unrelated repository is never treated as your fork.

This version has 44 automated tests with mocked GitHub responses, service-worker messages, storage restarts and panel DOM behavior. A real Chrome session, live OAuth authorization, live repository writes and hosted Actions runs were **not** validated in the build environment, which has no installed browser and blocks browser downloads/direct GitHub API traffic. The new diagnostics run in your Chrome installation to test that path directly. Run the [acceptance checklist](docs/TESTING.md) on your own demo repo before using it at the hackathon.

## Development

Use Node 22 or newer. Runtime code and automated tests have no dependencies.

```sh
npm test
npm run check
npm test --prefix sample
npm run build --prefix sample
```

After editing extension files, click **Reload** in `chrome://extensions`, close/reopen its workspace and reload your ChatGPT tab. See [architecture](docs/ARCHITECTURE.md) for the main modules and [testing](docs/TESTING.md) for the optional Chromium smoke script.

MIT licensed. This is an independent project; it is not affiliated with OpenAI or GitHub.
