import test from 'node:test';
import assert from 'node:assert/strict';
import {cartTotal} from '../src/cart.js';
test('sum item prices in cents', () => {
  assert.equal(cartTotal([{priceCents: 199, quantity: 2}, {priceCents: 501, quantity: 1}]), 899);
});
test('empty cart totals zero', () => assert.equal(cartTotal([]), 0));
test('reject fractional quantities', () => assert.throws(() => cartTotal([{priceCents:100, quantity:1.5}]), TypeError));
