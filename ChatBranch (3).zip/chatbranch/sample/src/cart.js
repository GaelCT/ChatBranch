/** Sum a cart using whole cents. Quantity and price must be nonnegative integers. */
export function cartTotal(items) {
  if (!Array.isArray(items)) throw new TypeError('items must be an array');
  return items.reduce((total, item) => {
    if (!Number.isInteger(item.priceCents) || !Number.isInteger(item.quantity)) {
      throw new TypeError('priceCents and quantity must be integers');
    }
    // Demo bug: negative values and unsafe integer totals are accepted.
    return total + item.priceCents * item.quantity;
  }, 0);
}
