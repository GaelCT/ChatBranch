# Cart demo for ChatBranch

This is a dependency-free JavaScript project with Node.js tests and CI. Node 22 or newer is required.

Run `npm test` and `npm run build`. The initial tests pass, but `cartTotal` contains a documented validation bug: it accepts negative prices and quantities and can overflow JavaScript's safe integer range.

To try ChatBranch on GitHub, create a public repository you own, then upload **the contents of this sample folder** to its root, including `.github/workflows/ci.yml`. Do not upload the outer ChatBranch project as the demo repo. Use the GitHub website or your usual git workflow for this initial upload.

Load your demo repo in ChatBranch. Select `src/cart.js`, `test/cart.test.js`, `package.json` and this README. Ask ChatGPT to reject negative or unsafe integer prices/quantities, reject unsafe totals, keep zero values valid, and add regression tests. Copy the prepared prompt into ChatGPT, import its response, review, and publish a draft PR.

The parent project's `examples/cart-fix.json` provides a complete known correction. It intentionally has no baseCommit because your first GitHub commit SHA will be different. Review its full replacements against this sample before publishing. It edits the source and adds a regression-test file; it does not overwrite the original tests.

GitHub Actions runs the existing tests and new regression tests for pushes and PRs, then builds an ESM library bundle in `dist/`. After a successful push to the repository's default branch, it delivers that bundle as a downloadable `cart-bundle` artifact in the workflow run. Artifacts expire after seven days. This is continuous delivery of a tested build; hosting deployment needs an actual deployment target and is not configured here. Nothing merges automatically. A green check only means the supplied tests passed; the initial green suite demonstrates why regression tests are needed.
