# Changes

## 0.2.0

- Remember OAuth sign-in across extension reloads and browser restarts using trusted local extension storage. Migrate an existing session credential when available.
- Verify the saved account and OAuth scopes with GitHub automatically; show verification time and separate API/account status. Cache successful checks for five minutes.
- Preserve a saved credential on network failures. Reconnect after access recovers; require authorization again after expiry/revocation or an explicit scope upgrade.
- Check Chrome host permissions and provide a user-clicked site-access recovery button, a public API test link, and whitelisted diagnostic copying.
- Preserve redacted transport error details and HTTP/non-JSON proxy errors. Follow normal read redirects after renames, use canonical repo names, and continue rejecting write redirects.
- Add visible controls for requesting missing public-repo/workflow scope while already connected.
- 44 automated tests pass, including restart, network recovery without a device code, revocation, permission handling and the complete mocked PR flow. Real Chrome/live OAuth and writes remain unverified in this build environment; in-browser diagnostics test the user's own connection.

## 0.1.1

- Public repo loading and copying file context now work before GitHub sign-in. Review and publishing continue to require sign-in.
- Loading displays progress and actionable failures beneath the repo controls, including missing repo, wrong branch, empty repo and failed commit/tree reads.
- Switching repos clears a base branch that the previous load automatically filled. A branch explicitly entered by the user is retained.
- Changing repo/branch inputs disables operations using the previous snapshot until the new selection loads successfully. Switching between branches at the same commit updates the workspace correctly.
- Failed operations retain their error text and re-enable Load repo for retry.
- Added public-load, stage-error and panel regression checks; 30 automated tests pass.

Real Chrome and live OAuth/GitHub writes remain unverified in the build environment. These changes address confirmed code behavior, but the exact cause of the user's reported load failure has not been identified without its error message or repo URL.

## 0.1.0

Initial unpacked Chrome extension with web ChatGPT response capture, public GitHub repo context, code imports, diff review, forks, branches, PRs and CI results; sample JavaScript tests/build/delivery workflow.
