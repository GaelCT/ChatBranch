import {diffLines, safePath, bytes, MAX_FILE_BYTES, MAX_FILES, MAX_TOTAL_BYTES} from './core/files.js';
const $=id=>document.getElementById(id);
let state={}, selected=new Set(), uploads=[], importMode='text', dirty=true, waiting=false, configLoaded=false, treeKey='', reviewKey='', pendingKey=0, baseAutofilled=false, repoInputsChanged=false;
function node(tag,text,className){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(className)n.className=className;return n;}
function notice(text,error=false){$('notice').textContent=text;$('notice').className=error?'error':'';$('notice').hidden=!text;}
async function send(message){const r=await chrome.runtime.sendMessage(message);if(!r?.ok)throw new Error(r?.error||'The extension did not respond. Reload it in chrome://extensions.');return r.value;}
function link(text,url){const a=node('a',text);try{const u=new URL(url);if(u.protocol==='https:'&&u.hostname==='github.com'){a.href=u.href;a.target='_blank';a.rel='noreferrer';}}catch{}return a;}
function controls(){
  const signed=Boolean(state.user)&&state.user.canPublish!==false&&(!state.connection||state.connection.state==='connected'), loaded=Boolean(state.snapshot)&&!repoInputsChanged, published=Boolean(state.published);
  $('load').disabled=waiting;
  $('copy-context').disabled=waiting||!loaded;
  $('review').disabled=waiting||!signed||!loaded;
  for(const id of ['refresh-ci','fix-pr','copy-failures'])$(id).disabled=waiting||!signed||!published;
  if(state.ci&&(state.ci.merged||state.ci.prState==='closed'))$('fix-pr').disabled=true;
  $('publish').disabled=waiting||!signed||!state.review||dirty||repoInputsChanged||!$('ack').checked;
  $('signin').disabled=waiting;$('save-config').disabled=waiting;
  $('check-connection').disabled=waiting;$('allow-access').disabled=waiting;
}
function renderConnection(){
  const c=state.connection;if(!c)return;
  const time=c.checkedAt?new Date(c.checkedAt).toLocaleTimeString():'';
  const apiTime=c.apiCheckedAt?new Date(c.apiCheckedAt).toLocaleTimeString():time;
  $('api-status').textContent=c.access?.api===false?'API: Chrome permission required':c.apiReachable===true?'API: reachable'+(apiTime?' · checked '+apiTime:''):c.apiReachable===false?'API: connection failed':'API: not checked yet';
  $('account-status').textContent=c.state==='connected'?`Account: verified @${c.login}${time?' · '+time:''}${c.canPublish?' · public repo publishing enabled':' · public_repo permission missing'}`:c.state==='checking'?'Account: checking saved sign-in…':c.state==='reauth_required'?'Account: sign in again':c.remembered?'Account: sign-in saved; GitHub identity verification failed.':'Account: signed out · public browsing available';
  const error=c.apiError||(c.state==='unreachable'||c.state==='permission_required'||c.state==='reauth_required'?c.message:'');
  $('connection-error').hidden=!error;$('connection-error').textContent=error;
  $('allow-access').hidden=c.access?.api!==false&&c.access?.oauth!==false;
  $('connection-version').textContent='ChatBranch '+(c.version||'0.2.0');
  $('signin').textContent='Sign in';
  if(c.state==='connected'&&(!c.canPublish||state.config?.workflow&&!c.workflow)){$('signin').hidden=false;$('signin').textContent=c.canPublish?'Add workflow access':'Grant repo access';}
  if(c.state==='checking'){$('identity').textContent='Checking saved GitHub sign-in…';$('auth-dot').className='dot';$('signin').hidden=true;$('logout').hidden=false;}
  else if(c.remembered&&c.state!=='connected'){$('identity').textContent=c.login?'Saved account @'+c.login:'GitHub sign-in saved';$('auth-dot').className='dot';$('signin').hidden=c.state!=='reauth_required';$('logout').hidden=false;}
}
function showLoadStatus(status){
  $('load-status').textContent=status?.message||'Public repos can be loaded before GitHub sign-in. Leave Base branch blank for the repo default.';
  $('load-status').className=status?.phase==='error'?'warning':'muted';
}
async function action(message,success){
  if(waiting)return;
  waiting=true;controls();notice('Working…');
  if(message.type==='load'){$('load').textContent='Loading…';showLoadStatus({phase:'loading',message:'Connecting to GitHub…'});}
  try{const value=await send(message);if(message.type!=='context')render(value);if(message.type==='load'||message.type==='load-pr')repoInputsChanged=false;notice(success||'Done.');return value;}
  catch(e){try{render(await send({type:'state'}));}catch{}notice(e.message,true);if(message.type==='load'||message.type==='load-pr')showLoadStatus({phase:'error',message:e.message});}
  finally{waiting=false;$('load').textContent='Load repo';controls();}
}
function markDirty(){dirty=true;$('ack').checked=false;controls();if(state.review)$('review-summary').textContent='Input changed. Review again.';}
function renderTree(){
  const root=$('file-tree');root.replaceChildren();
  const filter=$('file-filter').value.toLowerCase();
  const entries=state.snapshot?.entries.filter(e=>e.type==='blob'&&['100644','100755'].includes(e.mode)&&e.path.toLowerCase().includes(filter))||[];
  if(!state.snapshot){root.append(node('p','Load a repo to browse its files.','muted'));return;}
  for(const e of entries.slice(0,500)){
    const label=node('label');const cb=document.createElement('input');cb.type='checkbox';cb.checked=selected.has(e.path);cb.disabled=(e.size||0)>MAX_FILE_BYTES;cb.addEventListener('change',()=>{if(cb.checked&&selected.size>=25){cb.checked=false;notice('Select up to 25 context files.',true);return;}cb.checked?selected.add(e.path):selected.delete(e.path);$('selected-count').textContent=`${selected.size} selected · maximum 25`;});label.append(cb,node('span',e.path));root.append(label);
  }
  if(entries.length>500)root.append(node('p','Showing 500 paths. Search to narrow the list.','muted'));
  if(!entries.length)root.append(node('p','No matching text file paths.','muted'));
  $('selected-count').textContent=`${selected.size} selected · maximum 25`;
}
function renderDiffs(review){
  const root=$('diffs');root.replaceChildren();$('ack').checked=false;
  if(!review){$('review-summary').textContent='';$('unversioned').hidden=true;return;}
  let adds=0,removes=0;
  for(const file of review.files){
    const div=node('div',undefined,'diff'), heading=node('div',undefined,'diff-heading');
    const kind=file.action==='delete'?'DELETE':file.before===null?'NEW':'EDIT';
    heading.append(node('strong',file.path),node('span',kind,'tag'));div.append(heading);
    const pre=node('pre'), rows=diffLines(file.before,file.action==='delete'?null:file.content);
    adds+=rows.filter(r=>r.kind==='add').length;removes+=rows.filter(r=>r.kind==='remove').length;
    // Collapse long unchanged stretches while retaining the complete change.
    let unchanged=0, shown=0, truncated=false;
    for(let i=0;i<rows.length;i++){
      if(shown>=2000){truncated=true;break;}
      const r=rows[i];
      if(r.kind==='same'){
        const changeNear=rows.slice(Math.max(0,i-3),Math.min(rows.length,i+4)).some(x=>x.kind!=='same');
        if(!changeNear){unchanged++;continue;}
      }
      if(unchanged){pre.append(node('span',`  … ${unchanged} unchanged lines …`,'diff-line same'));unchanged=0;}
      pre.append(node('span',(r.kind==='add'?'+ ':r.kind==='remove'?'- ':'  ')+r.text,'diff-line '+r.kind));
      shown++;
    }
    if(unchanged)pre.append(node('span',`  … ${unchanged} unchanged lines …`,'diff-line same'));
    div.append(pre);
    if(file.action!=='delete')div.append(node('p',file.content.endsWith('\n')?'File ends with a newline.':'File has no final newline.','diff-note'));
    if(truncated){div.append(node('p','Diff preview limited to 2,000 lines. Review the complete files below.','warning'));const full=node('details'),summary=node('summary','View complete original and proposed files');full.append(summary);full.addEventListener('toggle',()=>{if(!full.open||full.dataset.loaded)return;full.dataset.loaded='true';for(const [label,text]of [['Original at loaded commit',file.before],['Proposed file',file.action==='delete'?null:file.content]]){full.append(node('p',label,'diff-note'));const area=document.createElement('textarea');area.readOnly=true;area.rows=12;area.value=text===null?'(File does not exist)':text;area.setAttribute('aria-label',label+' '+file.path);full.append(area);}});div.append(full);}
    root.append(div);
  }
  $('review-summary').textContent=`${review.files.length} file${review.files.length===1?'':'s'} · +${adds} −${removes}`;
  $('unversioned').hidden=!review.unversioned;
}
function renderCI(){
  $('results').hidden=!state.published;if(!state.published)return;
  const p=state.published;$('pr-link').textContent=`${p.upstream} · PR #${p.number} ↗`;$('pr-link').href=p.url;
  const ci=state.ci, explanations={none:'No checks were found for the current commit. This does not mean the tests passed. The repo may need a CI workflow, or fork checks may need approval.',pending:'Checks are running, queued or waiting for approval. Open GitHub for details.',passed:'All available checks succeeded (some may be skipped). Review whether the tests cover the requested behavior.',failed:'At least one check failed or was cancelled. Open its logs, then copy the results and load the PR branch to prepare a fix.',skipped:'All available checks were skipped or neutral. No passing test result was observed.',incomplete:'Some check endpoints could not be read. Open GitHub to verify the complete result.'};
  $('ci-badge').textContent=ci?({none:'No checks',passed:'Checks passed',failed:'Checks failed',pending:'In progress',skipped:'Skipped',incomplete:'Incomplete'}[ci.state]||ci.state):'Not checked';$('ci-badge').className='tag '+(ci?.state||'');
  $('ci-explanation').textContent=ci?(explanations[ci.state]||'Open GitHub for details.')+' Commit '+ci.sha.slice(0,7)+'.':'Refresh after GitHub starts your workflows.';
  $('checks').replaceChildren();
  if(ci){for(const item of ci.items){const row=node('div',undefined,'check-row'),body=node('div',undefined,'check-name');body.append(link(item.name,item.url));if(item.detail)body.append(node('p',item.detail.slice(0,3000),'muted'));row.append(body,node('span',item.state,'tag'));$('checks').append(row);}for(const w of ci.warnings)$('checks').append(node('p',w,'warning'));}
  $('fix-pr').disabled=waiting||Boolean(ci&&(ci.merged||ci.prState==='closed'));
}
function render(next){
  state=next;
  if(!configLoaded){$('client-id').value=state.config?.clientId||'';$('workflow-scope').checked=Boolean(state.config?.workflow);$('setup').open=!state.config?.clientId;configLoaded=true;}
  $('identity').textContent=state.user?'Signed in as @'+state.user.login:'Browse public repos';$('auth-dot').className='dot'+(state.user?' connected':'');$('signin').hidden=Boolean(state.user);$('logout').hidden=!state.user;$('account-detail').textContent=state.user?(state.user.workflow?'Public repos + workflow access':'Public repo access'):'Sign in to review changes and publish pull requests';
  renderConnection();
  showLoadStatus(state.loadStatus);
  $('device').hidden=!state.device;if(state.device){$('device-code').textContent=state.device.userCode;$('device-link').href=state.device.verificationUrl;}
  if(state.authError)notice(state.authError,true);
  const key=state.snapshot?[state.snapshot.fullName,state.snapshot.branch,state.snapshot.sha].join(':'):'';
  if(key!==treeKey){treeKey=key;repoInputsChanged=false;selected=new Set(state.snapshot?.suggested||[]);$('file-filter').value='';renderTree();if(state.snapshot){$('repo').value=state.snapshot.fullName;$('base').value=state.snapshot.branch;baseAutofilled=true;$('branch').value=state.snapshot.updatePR?state.snapshot.branch:'chatbranch/change-'+Date.now().toString(36);}markDirty();}
  $('snapshot').hidden=!state.snapshot;
  if(state.snapshot){const s=state.snapshot;$('repo-title').textContent=s.fullName;$('repo-meta').textContent=s.branch+' · '+s.sha.slice(0,7);$('target-hint').textContent=!state.user?'Public files loaded. Sign in with GitHub, then reload this repo to review and publish changes.':s.updatePR?'Updating PR #'+s.updatePR.number+' on this branch.':s.push?'A new branch will be created in this repository.':'A new branch will be created in your fork; the PR targets this repository.';$('branch').readOnly=Boolean(s.updatePR);$('publish-heading').textContent=s.updatePR?'Update the pull request':'Create a pull request';$('publish').textContent=s.updatePR?'Commit fix to PR branch':'Publish branch + pull request';}
  const rkey=state.review?.id||'';if(rkey!==reviewKey){reviewKey=rkey;renderDiffs(state.review);dirty=!state.review;if(state.review?.summary&&!$('pr-title').value)$('pr-title').value=state.review.summary;}
  if(state.pending&&state.pending.capturedAt!==pendingKey){pendingKey=state.pending.capturedAt;$('response').value=state.pending.text;setImport('text');markDirty();notice('ChatGPT response imported. Review it against your loaded repo.');void send({type:'pending-clear'}).catch(()=>{});}
  $('recovery').hidden=!state.recovery;if(state.recovery){$('recovery').replaceChildren(node('p','The branch was created, but the PR step needs another attempt. Keep the same reviewed changes and click Publish again.'),link('Open comparison on GitHub ↗',state.recovery.url));}
  renderCI();controls();
}
function setImport(mode){importMode=mode;$('text-input').hidden=mode!=='text';$('files-input').hidden=mode!=='files';$('text-tab').setAttribute('aria-selected',String(mode==='text'));$('files-tab').setAttribute('aria-selected',String(mode==='files'));markDirty();}
function renderUploads(){
  $('uploads').replaceChildren();uploads.forEach((f,i)=>{const row=node('div',undefined,'upload-row'),input=document.createElement('input');input.value=f.path;input.setAttribute('aria-label','Repository path for file '+(i+1));input.addEventListener('input',()=>{f.path=input.value;markDirty();});const buttons=node('div',undefined,'row'),remove=node('button','Remove');remove.addEventListener('click',()=>{uploads.splice(i,1);renderUploads();markDirty();});buttons.append(node('small',f.action==='delete'?'Delete this file':bytes(f.content)+' bytes · complete file'),remove);row.append(input,buttons);$('uploads').append(row);});
}
async function addFiles(input){
  try{
    const incoming=Array.from(input.files);if(incoming.length+uploads.length>MAX_FILES)throw new Error('Choose at most 50 files.');
    const next=[];let total=uploads.reduce((n,f)=>n+bytes(f.content||''),0);
    for(const file of incoming){const path=file.webkitRelativePath?file.webkitRelativePath.split('/').slice(1).join('/'):file.name;safePath(path);if(file.size>MAX_FILE_BYTES)throw new Error(path+' exceeds 512 KiB.');total+=file.size;if(total>MAX_TOTAL_BYTES)throw new Error('Files exceed 3 MiB.');let content;try{content=new TextDecoder('utf-8',{fatal:true}).decode(await file.arrayBuffer());}catch{throw new Error(path+' is not UTF-8 text.');}if(content.includes('\0'))throw new Error('Binary files are unsupported: '+path);next.push({path,action:'write',content});}
    uploads.push(...next);renderUploads();markDirty();notice(next.length+' files selected. Confirm the repo paths.');
  }catch(e){notice(e.message,true);}finally{input.value='';}
}
async function clipboard(text){try{await navigator.clipboard.writeText(text);return true;}catch{return false;}}
$('expand').addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('panel.html')}));
$('save-config').addEventListener('click',()=>action({type:'configure',clientId:$('client-id').value,workflow:$('workflow-scope').checked},'Setup saved. Sign in to authorize GitHub.'));
$('signin').addEventListener('click',()=>action({type:'signin'},'Enter the displayed code on GitHub.'));
$('logout').addEventListener('click',()=>action({type:'logout'},'Signed out. Session credentials and repo data cleared.'));
$('check-connection').addEventListener('click',()=>action({type:'connection-check'},'Connection check finished. See API and account status above.'));
$('copy-diagnostics').addEventListener('click',async()=>{
  const c=state.connection||{};
  const report=JSON.stringify({version:c.version||'0.2.0',reportedAt:new Date().toISOString(),api:{permission:c.access?.api,oauthSitePermission:c.access?.oauth,reachable:c.apiReachable,checkedAt:c.apiCheckedAt||c.checkedAt||null},account:{state:c.state,login:c.login||null,verifiedAt:c.checkedAt||null,publishing:c.canPublish||false,workflows:c.workflow||false},repo:$('repo').value,base:$('base').value||'(default)',loadMessage:$('load-status').textContent,connectionError:$('connection-error').textContent},null,2);
  notice(await clipboard(report)?'Connection diagnostics copied.':'Copy failed. The API and account status above show the connection result.',false);
});
$('allow-access').addEventListener('click',async()=>{
  try{
    // Keep this call inside the click gesture so Chrome can grant site access.
    const granted=await chrome.permissions.request({origins:['https://api.github.com/*','https://github.com/*']});
    if(!granted){notice('GitHub access was not granted. Allow the two GitHub sites in Chrome extension settings, then retry.',true);return;}
    await action({type:'connection-check'},'GitHub site access granted. See the connection result above.');
  }catch(e){notice(e.message,true);}
});
$('load').addEventListener('click',()=>action({type:'load',repo:$('repo').value,branch:$('base').value},'Repo loaded at a fixed commit. Select context files.'));
$('repo').addEventListener('input',()=>{repoInputsChanged=true;if(baseAutofilled){$('base').value='';baseAutofilled=false;}controls();});
$('base').addEventListener('input',()=>{repoInputsChanged=true;baseAutofilled=false;controls();});
$('file-filter').addEventListener('input',renderTree);
$('copy-context').addEventListener('click',async()=>{const result=await action({type:'context',paths:[...selected],task:$('task').value},'Prompt prepared.');if(result?.text){$('context-text').value=result.text;$('context-preview').hidden=false;$('view-context').hidden=false;notice(await clipboard(result.text)?'Prompt copied. Paste it into your ChatGPT conversation.':'Prompt ready below. Select and copy it manually.');}});
$('view-context').addEventListener('click',()=>{$('context-preview').open=true;$('context-text').focus();$('context-text').select();});
$('text-tab').addEventListener('click',()=>setImport('text'));$('files-tab').addEventListener('click',()=>setImport('files'));
for(const id of ['response','destination'])$(id).addEventListener('input',markDirty);
$('upload').addEventListener('change',()=>addFiles($('upload')));$('folder').addEventListener('change',()=>addFiles($('folder')));
$('add-delete').addEventListener('click',()=>{try{if(uploads.length>=MAX_FILES)throw new Error('Maximum 50 files.');const path=safePath($('delete-path').value.trim());uploads.push({path,action:'delete'});$('delete-path').value='';renderUploads();markDirty();}catch(e){notice(e.message,true);}});
$('review').addEventListener('click',()=>action({type:'review',...(importMode==='files'?{files:uploads}:{text:$('response').value,destination:$('destination').value})},'Diff ready. Review every file before publishing.'));
$('ack').addEventListener('change',controls);
$('pr-title').addEventListener('input',()=>{if(!$('commit-message').dataset.edited)$('commit-message').value=$('pr-title').value;});$('commit-message').addEventListener('input',()=>{$('commit-message').dataset.edited='true';});
$('publish').addEventListener('click',async()=>{const result=await action({type:'publish',reviewId:state.review?.id,branch:$('branch').value,title:$('pr-title').value,message:$('commit-message').value||$('pr-title').value,body:$('pr-body').value,draft:$('draft').checked},'Changes published. Open the PR or refresh its checks.');if(result?.published)$('results').scrollIntoView({behavior:'smooth',block:'start'});});
$('refresh-ci').addEventListener('click',()=>action({type:'ci'},'Latest checks loaded.'));
$('fix-pr').addEventListener('click',()=>action({type:'load-pr'},'PR branch loaded. Copy fresh context and prepare the fix; the next commit will update this PR.'));
$('copy-failures').addEventListener('click',async()=>{if(!state.ci){notice('Refresh checks first.',true);return;}const c=state.ci;let text=`PR: ${state.published.url}\nCurrent head: ${c.sha}\nChecks: ${c.state}\n\n`+c.items.map(i=>`${i.name}: ${i.state}\n${i.detail}\n${i.url||''}`).join('\n\n');text+='\n\nUse the fresh PR branch context to diagnose the failure and return a change bundle with regression tests. Ask for the failing job logs if these summaries are insufficient.';if(await clipboard(text))notice('Check results copied. Open failing logs on GitHub for the full error.');else{$('context-text').value=text;$('context-preview').hidden=false;$('context-preview').open=true;$('context-text').select();notice('Results ready in the prompt box. Copy them manually.');}});
async function refresh(){if(waiting)return;try{render(await send({type:'state'}));}catch(e){notice(e.message,true);}}
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='session'&&changes.loadStatus)showLoadStatus(changes.loadStatus.newValue);if(area==='session'&&(changes.pending||changes.authConnection||changes.apiHealth)||area==='local'&&changes.githubAuth)void refresh();});
void refresh();setInterval(()=>{if(state.device||state.connection?.remembered)void refresh();},5000);
