import {safeBranch, validateChanges} from './files.js';

const sleep = ms => new Promise(resolve => setTimeout(resolve,ms));
export function compareUrl(upstream, base, login, branch) {
  return `https://github.com/${upstream}/compare/${encodeURIComponent(base)}...${encodeURIComponent(login+':'+branch)}?expand=1`;
}

export async function writableTarget(api, snapshot, login, {delay = sleep} = {}) {
  if (snapshot.repo.permissions?.push) return {name:snapshot.fullName,fork:false};
  const root = snapshot.repo.source?.full_name || snapshot.fullName;
  let name = `${login}/${snapshot.repo.name}`;
  let fork;
  try { fork = await api.request('/repos/'+name); } catch(e) { if(e.status!==404)throw e; }
  if(fork && (!fork.fork || (fork.source?.full_name || fork.parent?.full_name)!==root || !fork.permissions?.push)) {
    name = `${login}/${snapshot.repo.name}-chatbranch`;
    try { fork = await api.request('/repos/'+name); } catch(e) { if(e.status!==404)throw e; else fork=null; }
    if(fork && (!fork.fork || (fork.source?.full_name || fork.parent?.full_name)!==root || !fork.permissions?.push)) throw new Error('Both fork names are occupied by other repos. Rename one on GitHub, then retry.');
  }
  if(!fork) {
    const created = await api.request(`/repos/${snapshot.fullName}/forks`,{method:'POST',body:{name:name.split('/')[1],default_branch_only:false}});
    name=created.full_name;
  }
  for(let attempt=0;attempt<10;attempt++) {
    try { await api.request(`/repos/${name}/git/commits/${snapshot.sha}`); return {name,fork:true}; }
    catch(e) { if(![404,409,422].includes(e.status))throw e; if(attempt===9)throw new Error('The fork is still preparing or does not have the selected base commit. Wait a minute and retry.'); await delay(2000); }
  }
}

export async function publishReview(api, review, options, login, {checkpoint=async()=>{},journal={},delay=sleep}={}) {
  const snapshot=review.snapshot;
  const files=validateChanges(review.files);
  const branch=safeBranch(options.branch);
  const title=String(options.title||'').trim();
  if(!title || title.length>200)throw new Error('Enter a pull request title of 1–200 characters.');
  if(!String(options.message||'').trim())throw new Error('Enter a commit message.');
  const updating=Boolean(snapshot.updatePR);
  if(branch===snapshot.repo.default_branch || (!updating && branch===snapshot.branch))throw new Error('Use a new branch. Publishing to the default or loaded base branch is disabled.');
  if(updating && branch!==snapshot.branch)throw new Error('Keep the loaded PR branch name when updating a pull request.');
  const save=async patch=>{Object.assign(journal,patch);await checkpoint({...journal});};
  // A worker/network interruption can occur after GitHub writes a ref but before
  // the checkpoint is saved. Recognize that exact commit as our successful write.
  if(journal.commit && !journal.branchReady) {
    try {
      const ref=await api.request(`/repos/${journal.target}/git/ref/heads/${encodeURIComponent(branch)}`);
      if(ref.object.sha===journal.commit)await save({branchReady:true});
    } catch(e) {if(e.status!==404)throw e;}
  }
  // Recovery after branch creation must not duplicate commits. The reviewed object is immutable.
  if(journal.branchReady) {
    const ref=await api.request(`/repos/${journal.target}/git/ref/heads/${encodeURIComponent(branch)}`);
    if(ref.object.sha!==journal.commit)throw new Error('The published branch changed since the interrupted operation. Reload that branch before continuing.');
  } else {
    const current=await api.request(`/repos/${snapshot.fullName}/git/ref/heads/${encodeURIComponent(snapshot.branch)}`);
    if(current.object.sha!==snapshot.sha)throw new Error('The base branch changed after review. Reload the repo and review the changes again.');
  }
  if(!journal.target) {
    const target=updating?{name:snapshot.fullName,fork:false}:await writableTarget(api,snapshot,login,{delay});
    await save({target:target.name,branch});
  }
  if(!updating && !journal.branchReady) {
    try { await api.request(`/repos/${journal.target}/git/ref/heads/${encodeURIComponent(branch)}`); throw new Error('That branch already exists. Choose a new branch name.'); }
    catch(e) { if(e.status!==404)throw e; }
  }
  if(!journal.commit) {
    const tree=await api.request(`/repos/${journal.target}/git/trees`,{method:'POST',body:{base_tree:snapshot.treeSha,tree:files.map(f=>({path:f.path,mode:snapshot.entries.find(e=>e.path===f.path)?.mode||'100644',type:'blob',...(f.action==='delete'?{sha:null}:{content:f.content})}))}});
    const commit=await api.request(`/repos/${journal.target}/git/commits`,{method:'POST',body:{message:options.message.trim(),tree:tree.sha,parents:[snapshot.sha]}});
    await save({commit:commit.sha});
  }
  if(!journal.branchReady) {
    if(updating) {
      // Recheck after creating objects; another writer may have changed the ref.
      const ref=await api.request(`/repos/${journal.target}/git/ref/heads/${encodeURIComponent(branch)}`);
      if(ref.object.sha!==snapshot.sha)throw new Error('Someone updated the PR branch. Reload it before publishing your fix.');
      await api.request(`/repos/${journal.target}/git/refs/heads/${encodeURIComponent(branch)}`,{method:'PATCH',body:{sha:journal.commit,force:false}});
    } else {
      await api.request(`/repos/${journal.target}/git/refs`,{method:'POST',body:{ref:'refs/heads/'+branch,sha:journal.commit}});
    }
    await save({branchReady:true});
  }
  const upstream=updating?snapshot.updatePR.upstream:snapshot.fullName;
  const base=updating?snapshot.updatePR.base:snapshot.branch;
  const head=journal.target===upstream?branch:journal.target.split('/')[0]+':'+branch;
  let pr;
  if(updating)pr=await api.request(`/repos/${upstream}/pulls/${snapshot.updatePR.number}`);
  else if(journal.pr)pr=journal.pr;
  else {
    const existing=await api.request(`/repos/${upstream}/pulls?state=open&head=${encodeURIComponent(journal.target.split('/')[0]+':'+branch)}&base=${encodeURIComponent(base)}`);
    pr=existing[0]||await api.request(`/repos/${upstream}/pulls`,{method:'POST',body:{title,body:String(options.body||''),base,head,draft:Boolean(options.draft)}});
    await save({pr:{number:pr.number,html_url:pr.html_url}});
  }
  return {upstream,base,target:journal.target,branch,sha:journal.commit,number:pr.number,url:pr.html_url,compareUrl:compareUrl(upstream,base,journal.target.split('/')[0],branch)};
}
