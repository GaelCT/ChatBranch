import {repoName, safePath, safeBranch, MAX_FILE_BYTES, isSensitivePath} from './files.js';

export class GitHubError extends Error {
  constructor(message, status, retryAfter = null) { super(message); this.name = 'GitHubError'; this.status = status; this.retryAfter = retryAfter;this.apiResponse=true; }
}
export class GitHubNetworkError extends Error {
  constructor(message){super(message);this.name='GitHubNetworkError';}
}
export class GitHub {
  constructor(token, fetcher = fetch, {onUnauthorized=async()=>{}}={}) { this.token = token; this.fetcher = fetcher;this.onUnauthorized=onUnauthorized; }
  async request(path, {method = 'GET', body, metadata=false} = {}) {
    if (!path.startsWith('/') || path.startsWith('//') || /[\r\n]/.test(path)) throw new Error('Invalid GitHub API path.');
    const url = new URL(path, 'https://api.github.com');
    if (url.origin !== 'https://api.github.com') throw new Error('Invalid API origin.');
    let res;
    let raw;
    try {
      // Read redirects are normal after a repository rename. Fetch removes the
      // Authorization header on a cross-origin redirect; CSP restricts hosts too.
      res = await this.fetcher(url.href, {method, redirect:method==='GET'?'follow':'error', credentials:'omit', headers:{'Accept':'application/vnd.github+json', 'X-GitHub-Api-Version':'2026-03-10', ...(this.token ? {'Authorization':'Bearer '+this.token} : {}), ...(body !== undefined ? {'Content-Type':'application/json'} : {})}, ...(body !== undefined ? {body:JSON.stringify(body)} : {}), signal:AbortSignal.timeout(20000)});
      if(res.url && new URL(res.url).origin!=='https://api.github.com')throw new Error('Response redirected outside api.github.com');
      raw=await res.text();
    } catch(e) {
      const reason=String(e?.message||e?.name||'Network error').replaceAll(this.token||'\0','[redacted]').slice(0,220);
      throw new GitHubNetworkError('Could not reach GitHub API ('+reason+'). Use Check connection and Allow GitHub access. If permissions are granted, Open API test to check whether your browser/network can reach api.github.com.');
    }
    if(res.status===401&&this.token)await this.onUnauthorized();
    let data;
    try { data = raw ? JSON.parse(raw) : null; }
    catch {const e=new GitHubError('GitHub API returned HTTP '+res.status+' with a non-JSON response. Open API test to check whether a network filter or proxy is blocking it.',res.status);e.apiResponse=false;throw e;}
    if (!res.ok) {
      let message = typeof data?.message === 'string' ? data.message : 'GitHub request failed.';
      if (res.status === 401) message = 'GitHub sign-in expired or was revoked. Sign in again.';
      if (res.status === 403 && res.headers.get('x-ratelimit-remaining') === '0') message = 'GitHub API rate limit reached. Retry after ' + new Date(Number(res.headers.get('x-ratelimit-reset'))*1000).toLocaleTimeString() + '.';
      if (Array.isArray(data?.errors)) message += ' ' + data.errors.map(x => typeof x === 'string' ? x : [x.field, x.code, x.message].filter(Boolean).join(': ')).join('; ');
      throw new GitHubError(message.slice(0, 1000), res.status, res.headers.get('retry-after'));
    }
    return metadata?{data,scopes:res.headers.get('x-oauth-scopes')}:data;
  }
  async snapshot(fullName, branch, {onProgress=async()=>{}}={}) {
    let name = repoName(fullName);
    await onProgress('Reading repository information…');
    let repo;
    try {repo = await this.request('/repos/' + name);}
    catch(e){if(e.status===404)throw new Error('Repository not found: '+name+'. Use a public repo URL such as https://github.com/owner/repo.');throw new Error('Could not read '+name+': '+e.message,{cause:e});}
    if (repo.private) throw new Error('This version supports public repositories only.');
    if (repo.archived || repo.disabled) throw new Error('This repository is archived or disabled.');
    name=repoName(repo.full_name||name);
    const selected = branch || repo.default_branch;
    if(!selected)throw new Error('This repository has no default branch yet. Add and commit its first file on GitHub, then load it again.');
    safeBranch(selected);
    await onProgress('Reading branch '+selected+'…');
    let ref;
    try {ref = await this.request(`/repos/${name}/git/ref/heads/${encodeURIComponent(selected)}`);}
    catch(e){if(e.status===404)throw new Error('Branch "'+selected+'" was not found in '+name+'. Leave Base branch blank to use the repository default.');if(e.status===409)throw new Error('GitHub could not read this branch: '+e.message+' If the repo is empty, commit a README first.');throw new Error('Could not read branch '+selected+': '+e.message,{cause:e});}
    if(!ref?.object?.sha)throw new Error('GitHub returned no commit for the selected branch.');
    await onProgress('Reading the branch commit…');
    let commit;
    try {commit = await this.request(`/repos/${name}/git/commits/${ref.object.sha}`);}
    catch(e){throw new Error('Could not read the selected commit: '+e.message,{cause:e});}
    if(!commit?.tree?.sha)throw new Error('GitHub returned no file tree for the selected commit.');
    await onProgress('Reading repository files…');
    let tree;
    try {tree = await this.request(`/repos/${name}/git/trees/${commit.tree.sha}?recursive=1`);}
    catch(e){throw new Error('Could not read repository files: '+e.message,{cause:e});}
    if(!Array.isArray(tree?.tree))throw new Error('GitHub returned an unreadable repository file list.');
    if (tree.truncated) throw new Error('This repository tree is too large for the first version. Choose a smaller repository.');
    return {repo, fullName:name, branch:selected, sha:ref.object.sha, treeSha:commit.tree.sha, entries:tree.tree.filter(e => e.type === 'blob' || e.type === 'commit')};
  }
  async text(snapshot, path) {
    safePath(path);
    const entry = snapshot.entries.find(e => e.path === path);
    if (!entry) return null;
    if (entry.type !== 'blob' || !['100644','100755'].includes(entry.mode)) throw new Error('Symlinks and submodules cannot be read or edited: ' + path);
    if (entry.size > MAX_FILE_BYTES) throw new Error(path + ' exceeds the 512 KiB text limit.');
    const blob = await this.request(`/repos/${snapshot.fullName}/git/blobs/${entry.sha}`);
    if (blob.encoding !== 'base64' || blob.size > MAX_FILE_BYTES) throw new Error('Unsupported or oversized file: ' + path);
    let content;
    try { content = new TextDecoder('utf-8', {fatal:true}).decode(Uint8Array.from(atob(blob.content.replace(/\s/g,'')), c => c.charCodeAt(0))); }
    catch { throw new Error('Only UTF-8 text files are supported: ' + path); }
    if (content.includes('\0')) throw new Error('Binary files are unsupported: ' + path);
    return content;
  }
}

export function suggestedFiles(entries) {
  return entries.filter(e => e.type === 'blob' && ['100644','100755'].includes(e.mode) && (e.size ?? 0) <= MAX_FILE_BYTES && !isSensitivePath(e.path) && /(^|\/)(README(?:\.md)?|CONTRIBUTING\.md|AGENTS\.md|package\.json|tsconfig\.json)$|^\.github\/workflows\/[^/]+\.ya?ml$/i.test(e.path)).slice(0, 12).map(e => e.path);
}

export function summarizeChecks(checks, statuses, runs) {
  const items = [
    ...checks.map(c => ({name:c.name, state:c.status === 'completed' ? c.conclusion || 'unknown' : c.status, url:c.html_url || c.details_url, detail:c.output?.summary || c.output?.title || ''})),
    ...statuses.map(s => ({name:s.context, state:s.state, url:s.target_url, detail:s.description || ''})),
    ...runs.map(r => ({name:r.name, state:r.status === 'completed' ? r.conclusion || 'unknown' : r.status, url:r.html_url, detail:r.status === 'waiting' ? 'This run may need maintainer approval.' : ''}))
  ];
  const fail = new Set(['failure','error','cancelled','timed_out','action_required','startup_failure','stale']);
  const complete = new Set(['success','neutral','skipped']);
  const state = !items.length ? 'none' : items.some(i=>fail.has(i.state)) ? 'failed' : items.some(i=>!complete.has(i.state)) ? 'pending' : items.some(i=>i.state==='success') ? 'passed' : 'skipped';
  return {state, items};
}

export async function readCI(api, published) {
  const pr = await api.request(`/repos/${published.upstream}/pulls/${published.number}`);
  const head = pr.head.sha;
  // Only results attached to this PR's current head or its current test merge count.
  const shaRepos = [{name:published.upstream,sha:head}];
  const mergeWarnings=[];
  if (pr.merge_commit_sha && pr.merge_commit_sha !== head && pr.state === 'open') {
    try {
      const merge=await api.request(`/repos/${published.upstream}/git/commits/${pr.merge_commit_sha}`);
      if(merge.parents?.some(p=>p.sha===head))shaRepos.push({name:published.upstream,sha:pr.merge_commit_sha});
      else mergeWarnings.push('GitHub’s test merge has not caught up with the current PR head. Refresh shortly.');
    }catch(e){mergeWarnings.push('Could not verify the PR test merge: '+e.message);}
  }
  if (pr.head.repo?.full_name && pr.head.repo.full_name !== published.upstream) shaRepos.push({name:pr.head.repo.full_name,sha:head});
  const checks=[], statuses=[], runs=[], warnings=[...mergeWarnings];
  for (const item of shaRepos) {
    const results = await Promise.allSettled([
      api.request(`/repos/${item.name}/commits/${item.sha}/check-runs?per_page=100`),
      api.request(`/repos/${item.name}/commits/${item.sha}/status?per_page=100`),
      api.request(`/repos/${item.name}/actions/runs?head_sha=${item.sha}&per_page=100`)
    ]);
    if (results[0].status === 'fulfilled') checks.push(...results[0].value.check_runs.filter(c => c.head_sha === item.sha)); else warnings.push('Check runs: '+results[0].reason.message);
    if (results[1].status === 'fulfilled') statuses.push(...(results[1].value.statuses || [])); else warnings.push('Commit statuses: '+results[1].reason.message);
    if (results[2].status === 'fulfilled') runs.push(...results[2].value.workflow_runs.filter(r => r.head_sha === item.sha)); else warnings.push('Actions: '+results[2].reason.message);
    for(const r of results)if(r.status==='fulfilled' && r.value.total_count>100)warnings.push('This commit has more than 100 results. Open GitHub for the complete check list.');
  }
  const unique = (rows, key) => [...new Map(rows.map(x => [key(x), x])).values()];
  // Select newest rerun of each workflow; old failures do not mask a successful rerun.
  const latest = new Map();
  for (const r of runs.sort((a,b)=>new Date(b.created_at)-new Date(a.created_at))) { const key=r.repository?.full_name+':'+r.workflow_id+':'+r.head_sha+':'+r.event; if(!latest.has(key))latest.set(key,r); }
  const result = summarizeChecks(unique(checks,c=>c.id), unique(statuses,s=>s.context+':'+s.url), [...latest.values()]);
  if (warnings.length && result.state === 'passed') result.state = 'incomplete';
  return {...result, warnings:[...new Set(warnings)], sha:head, prUrl:pr.html_url, number:pr.number, merged:pr.merged, prState:pr.state};
}
