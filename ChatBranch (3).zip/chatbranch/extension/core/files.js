export const MAX_FILES = 50;
export const MAX_FILE_BYTES = 512 * 1024;
export const MAX_TOTAL_BYTES = 3 * 1024 * 1024;
const encoder = new TextEncoder();
export const bytes = s => encoder.encode(s).byteLength;

export function repoName(value) {
  const input = String(value).trim();
  let full = input;
  if (/^https?:/i.test(input)) {
    const url = new URL(input);
    if (url.protocol !== 'https:' || url.hostname !== 'github.com' || url.username || url.password || url.port) throw new Error('Use an https://github.com/owner/repo URL.');
    full = url.pathname.replace(/^\/+|\/+$/g, '');
  }
  full = full.replace(/\.git$/, '');
  if (!/^[\w-]+\/[\w.-]+$/.test(full) || full.split('/').some(x => x === '.' || x === '..')) throw new Error('Enter owner/repo or its GitHub URL.');
  return full;
}

export function isSensitivePath(path) {
  return /(^|\/)(\.env(?:\..*)?|\.ssh|\.git|credentials(?:\.[^/]*)?|id_rsa|id_ed25519)(\/|$)/i.test(path) || /\.(pem|key|p12|pfx)$/i.test(path);
}
export function safePath(path) {
  if (typeof path !== 'string' || !path || path.length > 500 || path.trim() !== path || /[\\\x00-\x1f\x7f]/.test(path) || path.startsWith('/') || /^[A-Za-z]:/.test(path) || path.split('/').some(x => !x || x === '.' || x === '..')) throw new Error('Invalid relative file path: ' + String(path));
  if (isSensitivePath(path)) throw new Error('Secret or Git metadata files are excluded: ' + path);
  return path;
}
export function safeBranch(branch) {
  if (typeof branch !== 'string' || !branch || branch.length > 180 || /[\s~^:?*\[\\\x00-\x1f\x7f]/.test(branch) || branch.includes('..') || branch.includes('@{') || branch.startsWith('/') || branch.endsWith('/') || branch.endsWith('.') || branch === '@' || branch.split('/').some(x => !x || x.startsWith('.') || x.endsWith('.lock'))) throw new Error('Choose a valid Git branch name, such as chatbranch/fix-cart.');
  return branch;
}
export function validateChanges(files) {
  if (!Array.isArray(files) || !files.length || files.length > MAX_FILES) throw new Error(`Import between 1 and ${MAX_FILES} files.`);
  const seen = new Set(); let total = 0;
  return files.map(file => {
    const path = safePath(file.path);
    const key = path.toLowerCase();
    if (seen.has(key)) throw new Error('Duplicate file path: ' + path);
    seen.add(key);
    const action = file.action || 'write';
    if (!['write', 'delete'].includes(action)) throw new Error('Use write or delete for ' + path);
    if (action === 'delete') return {path, action};
    if (typeof file.content !== 'string' || file.content.includes('\0')) throw new Error('Text content is required for ' + path);
    const size = bytes(file.content);
    if (size > MAX_FILE_BYTES) throw new Error(path + ' exceeds the 512 KiB text limit.');
    total += size;
    if (total > MAX_TOTAL_BYTES) throw new Error('Imported text exceeds 3 MiB.');
    return {path, action, content: file.content};
  });
}

function fences(text) {
  const blocks = []; const rx = /^([ \t]*)(`{3,}|~{3,})([^\n]*)\n/gm;
  let m;
  while ((m = rx.exec(text))) {
    const close = new RegExp('^' + m[1] + m[2][0] + '{' + m[2].length + ',}[ \\t]*$', 'gm');
    close.lastIndex = rx.lastIndex;
    const end = close.exec(text);
    if (!end) throw new Error('An imported code block is missing its closing fence.');
    blocks.push({label:m[3].trim(), content:text.slice(rx.lastIndex, end.index), before:text.slice(0, m.index), start:m.index});
    rx.lastIndex = close.lastIndex;
  }
  return blocks;
}
function decodeEnvelope(text) {
  let value;
  try { value = JSON.parse(text); } catch { return null; }
  if (!value || typeof value !== 'object' || !Array.isArray(value.files)) return null;
  if (value.schemaVersion !== undefined && value.schemaVersion !== 1) throw new Error('Unsupported change bundle schema. Use schemaVersion: 1.');
  if (value.baseCommit !== undefined && !/^[a-f0-9]{40}$/i.test(value.baseCommit)) throw new Error('baseCommit must be a full 40-character commit SHA.');
  return {format:'bundle', baseCommit:value.baseCommit || null, summary:String(value.summary || '').slice(0, 500), files:validateChanges(value.files)};
}
export function parseImport(text, destination = '') {
  if (typeof text !== 'string' || bytes(text) > MAX_TOTAL_BYTES) throw new Error('Import exceeds 3 MiB.');
  const raw = text.trim();
  const json = decodeEnvelope(raw); if (json) return json;
  const directPatch = text.trimStart();
  if (/^(diff --git |--- )/.test(directPatch)) return {format:'patch', patch:directPatch + (directPatch.endsWith('\n') ? '' : '\n'), files:null};
  const blocks = fences(text);
  for (const b of blocks) { const envelope = decodeEnvelope(b.content.trim()); if (envelope) return envelope; }
  const patch = blocks.find(b => /^(diff --git |--- )/m.test(b.content));
  if (patch) return {format:'patch', patch:patch.content, files:null};
  const files = [];
  for (const b of blocks) {
    const previousLine = b.before.trimEnd().split('\n').at(-1).trim();
    // Paths must be explicit. A language label (e.g. javascript) is never a path.
    const heading = previousLine.match(/^(?:#{1,6}\s*)?(?:(?:updated |new )?file:\s*)?`([^`]+)`\s*$/i) || previousLine.match(/^(?:#{1,6}\s*)?(?:updated |new )?file:\s*(\S+)\s*$/i);
    const tagged = b.label.match(/^(?:\w+\s+)?(?:path|file)=(\S+)$/);
    if (heading || tagged) files.push({path:(heading || tagged)[1], action:'write', content:b.content});
  }
  if (files.length && files.length === blocks.length) return {format:'markdown', baseCommit:null, files:validateChanges(files)};
  if (destination && blocks.length <= 1) return {format:'single file', baseCommit:null, files:validateChanges([{path:destination, content:blocks.length ? blocks[0].content : text}])};
  throw new Error('Use a JSON change bundle, unified diff, or file-labelled code blocks. For one complete file, enter its destination path.');
}

export function patchPaths(patch) {
  const lines = patch.split('\n'); const paths = new Set();
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].startsWith('--- ') && lines[i + 1]?.startsWith('+++ ')) {
      for (const header of [lines[i], lines[i + 1]]) {
        const path = header.slice(4).split('\t')[0];
        if (path !== '/dev/null') paths.add(safePath(path.replace(/^[ab]\//, '')));
      }
      i++;
    }
  }
  if (!paths.size || paths.size > MAX_FILES) throw new Error('Patch must contain 1–50 text files.');
  return [...paths];
}

// Apply only exact hunks. No fuzzy matching and no shell commands.
export function applyPatch(patch, originals) {
  if (/^(GIT binary patch|Binary files |(?:old|new|deleted file|new file) mode (?:120000|160000)|rename (?:from|to) |copy (?:from|to) )/m.test(patch)) throw new Error('Binary files, symlinks, submodules and rename-only patches are unsupported. Use explicit text writes/deletes.');
  patchPaths(patch);
  const lines = patch.replace(/\r\n/g, '\n').split('\n'); const files = [];
  let i = 0;
  while (i < lines.length) {
    if (!lines[i].startsWith('--- ')) { i++; continue; }
    const oldPath = lines[i++].slice(4).split('\t')[0];
    if (!lines[i]?.startsWith('+++ ')) throw new Error('Patch is missing a +++ file header.');
    const newPath = lines[i++].slice(4).split('\t')[0];
    const path = safePath((newPath === '/dev/null' ? oldPath : newPath).replace(/^[ab]\//, ''));
    if (oldPath !== '/dev/null' && newPath !== '/dev/null' && oldPath.replace(/^[ab]\//, '') !== newPath.replace(/^[ab]\//, '')) throw new Error('Use separate write/delete entries for renames.');
    const original = originals.get(path);
    if (oldPath === '/dev/null' ? original !== null : typeof original !== 'string') throw new Error('Patch existence does not match the loaded repo: ' + path);
    const oldText = original ?? '';
    const oldLines = oldText ? oldText.split('\n') : [];
    if (oldText.endsWith('\n')) oldLines.pop();
    const output = []; let cursor = 0; let hunks = 0; let finalNewline = oldText.endsWith('\n');
    while (i < lines.length) {
      if (lines[i].startsWith('--- ') || lines[i].startsWith('diff --git ')) break;
      const h = lines[i].match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?:.*)$/);
      if (!h) { if (lines[i].trim()) throw new Error('Unsupported patch line: ' + lines[i].slice(0, 100)); i++; continue; }
      i++; hunks++;
      const oldCount = Number(h[2] ?? 1), newCount = Number(h[4] ?? 1);
      const at = oldCount === 0 ? Number(h[1]) : Number(h[1]) - 1;
      const newAt = newCount === 0 ? Number(h[3]) : Number(h[3]) - 1;
      if (at < cursor || at > oldLines.length) throw new Error('Patch hunk position does not match ' + path);
      output.push(...oldLines.slice(cursor, at)); cursor = at;
      if (newAt !== output.length) throw new Error('Patch new hunk position does not match ' + path);
      let removed = 0, added = 0, previousPrefix = '';
      while (i < lines.length && !lines[i].startsWith('@@ ') && !lines[i].startsWith('diff --git ') && !(removed === oldCount && added === newCount && lines[i].startsWith('--- '))) {
        const line = lines[i];
        if (line === '\\ No newline at end of file') {
          if (!previousPrefix) throw new Error('Invalid no-newline patch marker.');
          if (previousPrefix !== '-') finalNewline = false;
          i++; continue;
        }
        if (removed === oldCount && added === newCount) break;
        const prefix = line[0];
        if (![' ', '-', '+'].includes(prefix)) throw new Error('Invalid patch hunk in ' + path);
        const value = line.slice(1);
        if (prefix !== '+') {
          if (oldLines[cursor] !== value) throw new Error('Patch context differs from the loaded commit: ' + path + '. Load fresh repo context and regenerate.');
          cursor++; removed++;
        }
        if (prefix !== '-') { output.push(value); added++; finalNewline = true; }
        previousPrefix = prefix; i++;
      }
      if (removed !== oldCount || added !== newCount) throw new Error('Patch hunk counts differ for ' + path);
    }
    if (!hunks) throw new Error('Patch contains no text hunks for ' + path);
    output.push(...oldLines.slice(cursor));
    if (cursor < oldLines.length) finalNewline = oldText.endsWith('\n');
    const content = output.join('\n') + (finalNewline && output.length ? '\n' : '');
    if (newPath === '/dev/null' && content) throw new Error('Delete patch must remove the entire file: ' + path);
    files.push(newPath === '/dev/null' ? {path, action:'delete'} : {path, action:'write', content});
  }
  return validateChanges(files);
}

export function diffLines(before, after) {
  const a = before === null ? [] : before.split('\n'), b = after === null ? [] : after.split('\n');
  if (a.length * b.length > 400000) {
    let p = 0, q = 0;
    while (p < a.length && p < b.length && a[p] === b[p]) p++;
    while (q < a.length-p && q < b.length-p && a[a.length-1-q] === b[b.length-1-q]) q++;
    return [...a.slice(0,p).map(text=>({kind:'same',text})), ...a.slice(p,a.length-q).map(text=>({kind:'remove',text})), ...b.slice(p,b.length-q).map(text=>({kind:'add',text})), ...a.slice(a.length-q).map(text=>({kind:'same',text}))];
  }
  const dp = Array.from({length:a.length+1},()=>new Uint32Array(b.length+1));
  for(let i=a.length-1;i>=0;i--) for(let j=b.length-1;j>=0;j--) dp[i][j]=a[i]===b[j]?1+dp[i+1][j+1]:Math.max(dp[i+1][j],dp[i][j+1]);
  const out=[];let i=0,j=0;
  while(i<a.length||j<b.length) {
    if(i<a.length&&j<b.length&&a[i]===b[j]) out.push({kind:'same',text:a[i++]}),j++;
    else if(j<b.length&&(i===a.length||dp[i][j+1]>=dp[i+1][j])) out.push({kind:'add',text:b[j++]});
    else out.push({kind:'remove',text:a[i++]});
  }
  return out;
}
