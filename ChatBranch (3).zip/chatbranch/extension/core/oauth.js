export const DEVICE_GRANT = 'urn:ietf:params:oauth:grant-type:device_code';
async function post(fetcher, path, params) {
  let response;
  try { response = await fetcher('https://github.com/login/' + path, {method:'POST', redirect:'error', headers:{Accept:'application/json','Content-Type':'application/x-www-form-urlencoded'}, body:new URLSearchParams(params).toString(), signal:AbortSignal.timeout(20000)}); }
  catch(e) {const reason=String(e?.message||'Network error').replaceAll(params.device_code||'\0','[redacted]').slice(0,180);throw new Error('Cannot reach GitHub sign-in ('+reason+'). Use Allow GitHub access and check your network connection.');}
  let value; try { value=await response.json(); } catch { throw new Error('GitHub sign-in returned HTTP '+response.status+' with an unreadable response. Check whether your network permits github.com.'); }
  if(!response.ok) throw new Error(value.error_description || value.error || 'GitHub sign-in failed.');
  return value;
}
export async function startDevice(clientId, workflow = false, fetcher = fetch, now = Date.now()) {
  if(!/^[A-Za-z0-9_.-]{10,100}$/.test(clientId)) throw new Error('Enter the client ID from your GitHub OAuth app.');
  const r = await post(fetcher,'device/code',{client_id:clientId,scope:workflow?'public_repo workflow':'public_repo'});
  if(r.error) throw new Error(r.error_description || (r.error==='device_flow_disabled'?'Enable Device Flow in your GitHub OAuth app settings.':r.error));
  if(!r.device_code || !r.user_code || !r.expires_in) throw new Error('GitHub did not return a device sign-in code.');
  return {clientId, workflow, deviceCode:r.device_code, userCode:r.user_code, verificationUrl:'https://github.com/login/device', interval:Math.max(5,Number(r.interval)||5), expiresAt:now+r.expires_in*1000, nextPoll:now+Math.max(5,Number(r.interval)||5)*1000};
}
export async function pollDevice(device, fetcher = fetch, now = Date.now()) {
  if(now >= device.expiresAt) return {error:'The sign-in code expired. Start sign-in again.'};
  if(now < device.nextPoll) return {device};
  const r = await post(fetcher,'oauth/access_token',{client_id:device.clientId,device_code:device.deviceCode,grant_type:DEVICE_GRANT});
  if(r.access_token) return {token:r.access_token,scope:r.scope||'',expiresAt:r.expires_in?now+Number(r.expires_in)*1000:null};
  if(r.error==='authorization_pending') return {device:{...device,nextPoll:now+device.interval*1000}};
  if(r.error==='slow_down') return {device:{...device,interval:device.interval+5,nextPoll:now+(device.interval+5)*1000}};
  const messages={access_denied:'GitHub sign-in was declined.',expired_token:'The sign-in code expired. Start sign-in again.',incorrect_client_credentials:'The OAuth client ID is incorrect.',device_flow_disabled:'Enable Device Flow in your OAuth app settings.'};
  return {error:messages[r.error]||r.error_description||'GitHub sign-in failed. Start again.'};
}
