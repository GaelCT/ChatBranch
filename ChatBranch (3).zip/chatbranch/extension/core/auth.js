import {GitHub} from './github.js';
export const VERIFY_TTL=5*60*1000;
const RETRY_DELAY=30*1000;
export function scopeList(value){return String(value||'').split(/[ ,]+/).filter(Boolean);}

// Only the service worker uses this module. Tokens never enter the UI model.
export class AuthManager{
  constructor({local,session,fetcher=(...args)=>fetch(...args),now=Date.now}){
    Object.assign(this,{local,session,fetcher,now});this.pending=null;this.revision=0;
    this.ready=this.initialize();
  }
  async initialize(){
    await this.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
    await this.session.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
    const {githubAuth}=await this.local.get('githubAuth'),{auth:legacy}=await this.session.get('auth');
    const auth=githubAuth||legacy;
    if(auth && (!githubAuth||!auth.credentialId))await this.local.set({githubAuth:{...auth,credentialId:auth.credentialId||crypto.randomUUID()}});
    if(legacy)await this.session.remove('auth');
  }
  async saved(){await this.ready;return (await this.local.get('githubAuth')).githubAuth||null;}
  async same(auth,revision){const current=await this.saved();return this.revision===revision&&current?.credentialId===auth.credentialId;}
  async clear({state='signed_out',message='Sign in to publish changes.',apiReachable=null}={}){
    await this.ready;this.revision++;
    await this.local.remove('githubAuth');await this.session.remove('auth');
    await this.session.set({authConnection:{state,message,checkedAt:this.now(),apiReachable}});
  }
  async invalidate(credentialId){const auth=await this.saved();if(auth?.credentialId===credentialId)await this.clear({state:'reauth_required',message:'GitHub rejected the saved sign-in. Sign in again.',apiReachable:true});}
  async networkFailure(message){
    const auth=await this.saved(),s=await this.status();
    const update={apiHealth:{reachable:false,checkedAt:this.now(),error:message}};
    if(auth)update.authConnection={state:'unreachable',credentialId:auth.credentialId,checkedAt:s.checkedAt,apiReachable:false,retryAt:this.now()+RETRY_DELAY,message};
    await this.session.set(update);
  }
  client(auth){return new GitHub(auth?.token||null,this.fetcher,{onUnauthorized:async()=>{if(auth)await this.invalidate(auth.credentialId);}});}
  async accept(result,{isCurrent=()=>true}={}){
    await this.ready;const revision=this.revision;
    if(this.revision!==revision||!isCurrent())return false;
    const auth={token:result.token,scope:result.scope||'',expiresAt:result.expiresAt||null,login:null,credentialId:crypto.randomUUID()};
    await this.local.set({githubAuth:auth});
    if(this.revision!==revision||!isCurrent()){const current=await this.saved();if(current?.credentialId===auth.credentialId)await this.local.remove('githubAuth');return false;}
    await this.verify({force:true});
    return true;
  }
  async status(){
    const auth=await this.saved(),{authConnection:c}=await this.session.get('authConnection');
    if(!auth)return c?.state==='reauth_required'?c:{state:'signed_out',message:'Sign in to publish changes.',apiReachable:c?.apiReachable??null,checkedAt:c?.checkedAt||null};
    const record=c?.credentialId===auth.credentialId?c:null;
    const expired=Boolean(auth.expiresAt&&this.now()>=auth.expiresAt);
    const stale=record?.state==='connected'&&this.now()-record.checkedAt>=VERIFY_TTL;
    const state=expired?'reauth_required':!record||stale?'checking':record.state;
    const scopes=scopeList(auth.scope);
    return {state,login:auth.login,remembered:true,checkedAt:record?.checkedAt||null,apiReachable:record?.apiReachable??null,workflow:scopes.includes('workflow'),canPublish:state==='connected'&&(scopes.includes('public_repo')||scopes.includes('repo')),message:state==='checking'?'Checking saved GitHub sign-in…':expired?'Saved GitHub sign-in expired.':record.message,needsCheck:expired||!record||stale||(record.state!=='connected'&&this.now()>=(record.retryAt||0))};
  }
  async verify({force=false}={}){
    if(this.pending)return this.pending;
    this.pending=this.runVerification(force).finally(()=>{this.pending=null;});return this.pending;
  }
  async runVerification(force){
    const auth=await this.saved();if(!auth)return this.status();
    const revision=this.revision,status=await this.status();
    if(!force&&!status.needsCheck)return status;
    if(!auth.token||auth.expiresAt&&this.now()>=auth.expiresAt){await this.clear({state:'reauth_required',message:'The saved GitHub sign-in expired. Sign in again.'});return this.status();}
    await this.session.set({authConnection:{state:'checking',credentialId:auth.credentialId,checkedAt:status.checkedAt,apiReachable:status.apiReachable,message:'Checking saved GitHub sign-in…'}});
    try{
      const response=await this.client(auth).request('/user',{metadata:true});
      if(!response.data?.login)throw new Error('GitHub did not return an authenticated username.');
      if(!await this.same(auth,revision))return this.status();
      const updated={...auth,login:response.data.login,scope:response.scopes??auth.scope};
      if(updated.login!==auth.login||updated.scope!==auth.scope)await this.local.set({githubAuth:updated});
      if(!await this.same(auth,revision))return this.status();
      await this.session.set({authConnection:{state:'connected',credentialId:auth.credentialId,checkedAt:this.now(),apiReachable:true,message:'GitHub verified @'+updated.login+'.'},apiHealth:{reachable:true,checkedAt:this.now(),error:''}});
    }catch(e){
      if(await this.same(auth,revision))await this.session.set({authConnection:{state:'unreachable',credentialId:auth.credentialId,checkedAt:status.checkedAt,apiReachable:e.apiResponse===true,retryAt:this.now()+RETRY_DELAY,message:e.message},apiHealth:{reachable:e.apiResponse===true,checkedAt:this.now(),error:e.message}});
    }
    return this.status();
  }
  async user(){const s=await this.status();return s.state==='connected'?{login:s.login,workflow:s.workflow,canPublish:s.canPublish}:null;}
  async require(){
    await this.verify();const status=await this.status(),auth=await this.saved();
    if(!auth||status.state!=='connected')throw new Error(status.message||'Sign in with GitHub first.');
    if(!status.canPublish)throw new Error('This GitHub token does not grant public_repo access. Sign in again with this OAuth app.');
    return {auth,api:this.client(auth)};
  }
}
