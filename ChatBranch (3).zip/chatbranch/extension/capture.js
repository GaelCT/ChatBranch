(() => {
  const marker='data-chatbranch-button';
  function extract(message) {
    const markdown=message.querySelector('.markdown')||message;
    const clone=markdown.cloneNode(true);
    clone.querySelectorAll('button, ['+marker+'], script, style').forEach(n=>n.remove());
    // Reconstruct fences because rendered ChatGPT messages omit their delimiters.
    clone.querySelectorAll('pre').forEach(pre=>{
      const code=pre.querySelector('code'); if(!code)return;
      const language=Array.from(code.classList).find(x=>x.startsWith('language-'))?.slice(9)||'';
      const content=code.textContent||'';
      const runs=[...content.matchAll(/`+/g)].map(x=>x[0].length);
      const fence='`'.repeat(Math.max(3,...runs.map(n=>n+1)));
      pre.replaceWith(document.createTextNode('\n'+fence+language+'\n'+content+(content.endsWith('\n')?'':'\n')+fence+'\n'));
    });
    clone.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li').forEach(n=>{n.prepend(document.createTextNode('\n'));n.append(document.createTextNode('\n'));});
    clone.querySelectorAll('code').forEach(n=>{n.replaceWith(document.createTextNode('`'+n.textContent+'`'));});
    return (clone.textContent||'').trim();
  }
  function attach() {
    document.querySelectorAll('[data-message-author-role="assistant"]').forEach(message=>{
      if(message.querySelector('['+marker+']'))return;
      const button=document.createElement('button');button.setAttribute(marker,'');button.type='button';button.textContent='Send to ChatBranch';
      Object.assign(button.style,{margin:'12px 0',padding:'7px 12px',border:'1px solid #708577',borderRadius:'8px',background:'#e8f4eb',color:'#153e29',font:'500 12px system-ui',cursor:'pointer'});
      button.addEventListener('click',async()=>{
        button.disabled=true;
        try{const result=await chrome.runtime.sendMessage({type:'capture',text:extract(message)});button.textContent=result?.ok?'Sent — open ChatBranch':result?.error||'Could not send. Paste manually.';}
        catch{button.textContent='Reload this page to reconnect ChatBranch.';}
        finally{button.disabled=false;}
      });
      message.append(button);
    });
  }
  let timer;
  const observer=new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(attach,300);});
  observer.observe(document.documentElement,{childList:true,subtree:true});attach();
})();
