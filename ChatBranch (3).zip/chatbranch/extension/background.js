import {GitHub, suggestedFiles, readCI} from './core/github.js';
import {parseImport, patchPaths, applyPatch, validateChanges, bytes, MAX_TOTAL_BYTES, isSensitivePath, safePath, repoName} from './core/files.js';
import {startDevice, pollDevice} from './core/oauth.js';
import {publishReview, compareUrl} from './core/publish.js';
import {AuthManager} from './core/auth.js';

const session=chrome.storage.session;
const authStore=new AuthManager({local:chrome.storage.local,session});
let busy=false, polling=false, authGeneration=0;
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='oauth')void poll().catch(async e=>{await session.set({authError:e.message});});});

async function hostAccess(){
  const [api,oauth]=await Promise.all([
    chrome.permissions.contains({origins:['https://api.github.com/*']}),
    chrome.permissions.contains({origins:['https://github.com/*']})
  ]);return {api,oauth};
}
async function api({publicRead=false}={}) {
  await authStore.ready;
  if(!(await hostAccess()).api)throw new Error('Chrome has not granted GitHub API access. Click Allow GitHub access at the top of ChatBranch, then retry.');
  if(publicRead){const auth=await authStore.saved();return {api:authStore.client(auth),auth};}
  return authStore.require();
}
async function view() {
  const s=await session.get(null), {config}=await chrome.storage.local.get('config');
  const access=await hostAccess(),authStatus=await authStore.status();
  const connection={...authStatus,access,version:chrome.runtime.getManifest().version};
  if(!access.api){connection.state='permission_required';connection.message='Chrome has not granted access to api.github.com. Click Allow GitHub access.';connection.apiReachable=false;connection.canPublish=false;}
  if(s.apiHealth && authStatus.state!=='connected' && access.api){connection.apiReachable=s.apiHealth.reachable;connection.apiCheckedAt=s.apiHealth.checkedAt;if(s.apiHealth.error)connection.apiError=s.apiHealth.error;}
  return {config:config||{},connection,user:access.api?await authStore.user():null,device:s.device?{userCode:s.device.userCode,verificationUrl:s.device.verificationUrl,expiresAt:s.device.expiresAt}:null,authError:s.authError||'',loadStatus:s.loadStatus||null,snapshot:s.snapshot?{fullName:s.snapshot.fullName,branch:s.snapshot.branch,sha:s.snapshot.sha,defaultBranch:s.snapshot.repo.default_branch,push:Boolean(s.snapshot.repo.permissions?.push),entries:s.snapshot.entries.filter(e=>!isSensitivePath(e.path)),suggested:suggestedFiles(s.snapshot.entries),updatePR:s.snapshot.updatePR||null}:null,review:s.review?{id:s.review.id,format:s.review.format,summary:s.review.summary,baseCommit:s.review.baseCommit,files:s.review.files,unversioned:s.review.unversioned}:null,pending:s.pending||null,published:s.published||null,ci:s.ci||null,recovery:s.journal?.branchReady?{target:s.journal.target,branch:s.journal.branch,url:compareUrl(s.snapshot.updatePR?.upstream||s.snapshot.fullName,s.snapshot.updatePR?.base||s.snapshot.branch,s.journal.target.split('/')[0],s.journal.branch)}:null,busy};
}
async function poll() {
  if(polling)return;
  polling=true;
  try {
    const {device}=await session.get('device'); if(!device)return;
    const generation=authGeneration;
    let result;
    try{result=await pollDevice(device);}
    catch(e){
      const current=(await session.get('device')).device;
      if(generation===authGeneration&&current?.deviceCode===device.deviceCode)await session.set({device:{...device,nextPoll:Date.now()+device.interval*1000}});
      throw e;
    }
      const current=(await session.get('device')).device;
      if(generation!==authGeneration || !current || current.deviceCode!==device.deviceCode)return;
    if(result.device)await session.set({device:result.device});
    else {
      if(result.token) {
        await authStore.accept(result,{isCurrent:()=>generation===authGeneration});
        if(generation!==authGeneration)return;
        await session.set({authError:''});
      } else await session.set({authError:result.error});
      await session.remove('device');await chrome.alarms.clear('oauth');
    }
  } finally {polling=false;}
}
async function originals(apiClient,snapshot,paths) {
  const map=new Map();let total=0;
  // Bounded concurrency avoids bursting secondary API limits.
  for(let i=0;i<paths.length;i+=4) {
    const results=await Promise.all(paths.slice(i,i+4).map(async path=>[path,await apiClient.text(snapshot,path)]));
    for(const [path,text] of results) {total+=bytes(text||'');if(total>MAX_TOTAL_BYTES)throw new Error('Original files exceed the 3 MiB review limit.');map.set(path,text);}
  }
  return map;
}
async function loadSnapshot(apiClient,name,branch,updatePR=null) {
  try{
    const onProgress=async message=>session.set({loadStatus:{phase:'loading',message}});
    const snapshot=await apiClient.snapshot(name,branch,{onProgress});
    if(snapshot.entries.length>15000 || bytes(JSON.stringify(snapshot))>1500000)throw new Error('Repository is too large for this version. Choose a smaller repo.');
    if(updatePR) snapshot.updatePR=updatePR;
    await session.remove(['review','journal','publishOptions','ci']);
    await session.set({snapshot,loadStatus:{phase:'loaded',message:`Loaded ${snapshot.fullName} · ${snapshot.branch} · ${snapshot.entries.length} file paths.`}});
    await session.set({apiHealth:{reachable:true,checkedAt:Date.now(),error:''}});
    if((await authStore.status()).state==='unreachable')void authStore.verify({force:true});
  }catch(e){
    let cause=e;while(cause?.cause)cause=cause.cause;
    if(cause?.name==='GitHubNetworkError'||cause?.apiResponse===false)await authStore.networkFailure(e.message);
    await session.set({loadStatus:{phase:'error',message:e.message}});throw e;
  }
}

async function handle(m) {
  await authStore.ready;
  if(m.type==='state'){
    await poll();const status=await authStore.status();
    if(status.needsCheck&&(await hostAccess()).api)void authStore.verify().catch(async e=>session.set({authError:e.message}));
    return view();
  }
  if(m.type==='pending-clear'){await session.remove('pending');return view();}
  if(busy)throw new Error('Wait for the current operation to finish.');
  busy=true;
  try {
    if(m.type==='configure') {
      const clientId=String(m.clientId||'').trim();
      if(!/^[A-Za-z0-9_.-]{10,100}$/.test(clientId))throw new Error('Enter your GitHub OAuth app client ID.');
      const old=(await chrome.storage.local.get('config')).config;
      await chrome.storage.local.set({config:{clientId,workflow:Boolean(m.workflow)}});
      if(old?.clientId!==clientId){authGeneration++;await authStore.clear();await session.remove(['device','authError','snapshot','review','journal','publishOptions','published','ci','loadStatus']);}
    } else if(m.type==='signin') {
      const {config}=await chrome.storage.local.get('config');
      const access=await hostAccess();if(!access.oauth||!access.api)throw new Error('Click Allow GitHub access before signing in.');
      const device=await startDevice(config?.clientId||'',Boolean(config?.workflow));
      authGeneration++;
      await authStore.clear();
      await session.remove(['snapshot','review','journal','publishOptions','published','ci','loadStatus','apiHealth']);
      await session.set({device,authError:''});await chrome.alarms.create('oauth',{periodInMinutes:0.5});
    } else if(m.type==='logout') {
      authGeneration++;
      await authStore.clear();
      await session.clear();await chrome.alarms.clear('oauth');
    } else if(m.type==='connection-check') {
      const access=await hostAccess();
      if(!access.api)throw new Error('Chrome has not granted access to api.github.com. Click Allow GitHub access.');
      const saved=await authStore.saved();
      if(saved){const result=await authStore.verify({force:true});await session.set({apiHealth:{reachable:result.apiReachable===true,checkedAt:Date.now(),error:result.apiReachable?'':result.message}});}
      else {
        try{await new GitHub(null).request('/rate_limit');await session.set({apiHealth:{reachable:true,checkedAt:Date.now(),error:''}});}
        catch(e){await session.set({apiHealth:{reachable:e.apiResponse===true,checkedAt:Date.now(),error:e.message}});}
      }
    } else if(m.type==='load') {
      const a=await api({publicRead:true});await loadSnapshot(a.api,repoName(m.repo),String(m.branch||'').trim());
    } else if(m.type==='load-pr') {
      const a=await api(),{published}=await session.get('published');
      if(!published)throw new Error('Create a pull request first.');
      const pr=await a.api.request(`/repos/${published.upstream}/pulls/${published.number}`);
      if(pr.state!=='open')throw new Error('This PR is closed. Load the repo to start a new PR.');
      if(!pr.head.repo)throw new Error('The PR branch repository is no longer available.');
      const target=await a.api.request('/repos/'+pr.head.repo.full_name);
      if(!target.permissions?.push)throw new Error('Your account cannot update this PR branch.');
      await loadSnapshot(a.api,pr.head.repo.full_name,pr.head.ref,{upstream:published.upstream,base:pr.base.ref,number:pr.number,url:pr.html_url});
    } else if(m.type==='context') {
      const a=await api({publicRead:true}),{snapshot}=await session.get('snapshot');
      if(!snapshot)throw new Error('Load a repository first.');
      if(!Array.isArray(m.paths)||m.paths.length>25)throw new Error('Select up to 25 context files.');
      const paths=[...new Set(m.paths.map(safePath))];
      const map=await originals(a.api,snapshot,paths);
      const task=String(m.task||'').trim().slice(0,12000);
      const template={schemaVersion:1,baseCommit:snapshot.sha,summary:'Brief description',files:[{path:'src/example.js',action:'write',content:'Complete replacement file contents, including final newline when appropriate'}]};
      let text=`Repository: ${snapshot.fullName}\nBranch: ${snapshot.branch}\nBase commit: ${snapshot.sha}\n\nTask: ${task || 'Describe the change you want.'}\n\nRead the supplied repo instructions and files. Return code changes and meaningful tests for the requested behavior. Use existing CI when present. Do not include shell commands as file changes. Return a single JSON change bundle in this format (replace the example file, keep the baseCommit):\n${JSON.stringify(template,null,2)}\n\nUse action "delete" without content for a deletion. Use full replacement file contents for writes, never placeholders or partial snippets. Only change files needed for the task. If more context is needed, ask for file paths first. Do not assume unprovided files.\n\nRepository file paths (first 300):\n`;
      text+=snapshot.entries.filter(e=>e.type==='blob'&&!isSensitivePath(e.path)).slice(0,300).map(e=>e.path).join('\n');
      for(const [path,content]of map)if(content!==null)text+=`\n\n=== FILE: ${path} ===\n${content}\n=== END FILE ===`;
      if(bytes(text)>MAX_TOTAL_BYTES)throw new Error('Context exceeds 3 MiB. Select fewer files.');
      return {text};
    } else if(m.type==='review') {
      const a=await api(),{snapshot}=await session.get('snapshot');
      if(!snapshot)throw new Error('Load a repository first.');
      const imported=m.files?{format:'uploaded files',files:validateChanges(m.files),baseCommit:null}:parseImport(String(m.text||''),String(m.destination||'').trim());
      if(imported.baseCommit && imported.baseCommit!==snapshot.sha)throw new Error('The bundle baseCommit differs from the loaded commit. Load fresh context and regenerate the changes.');
      const paths=imported.format==='patch'?patchPaths(imported.patch):imported.files.map(f=>f.path);
      const before=await originals(a.api,snapshot,paths);
      const changes=imported.format==='patch'?applyPatch(imported.patch,before):imported.files;
      if(changes.some(f=>f.path.startsWith('.github/workflows/'))&&!a.auth.scope.split(/[ ,]+/).includes('workflow'))throw new Error('Workflow changes need the workflow scope. Enable it under GitHub setup and sign in again.');
      const files=changes.map(f=>({...f,before:before.get(f.path)})).filter(f=>f.action==='delete'?f.before!==null:f.content!==f.before);
      if(!files.length)throw new Error('There are no changes relative to the loaded commit.');
      const deleted=changes.find(f=>f.action==='delete'&&before.get(f.path)===null);if(deleted)throw new Error('Cannot delete a missing file: '+deleted.path);
      // Reject file/directory collisions before touching GitHub.
      const remaining=snapshot.entries.map(e=>e.path).filter(p=>!files.some(f=>f.path===p&&f.action==='delete'));
      for(const f of files.filter(f=>f.action==='write')) {
        if(remaining.some(p=>p!==f.path&&(p.startsWith(f.path+'/')||f.path.startsWith(p+'/'))))throw new Error('File/directory path collision: '+f.path);
      }
      const review={id:crypto.randomUUID(),snapshotKey:[snapshot.fullName,snapshot.branch,snapshot.sha].join(':'),files,format:imported.format,summary:imported.summary||'',baseCommit:snapshot.sha,unversioned:!imported.baseCommit&&imported.format!=='patch'};
      if(bytes(JSON.stringify(review))+bytes(JSON.stringify(snapshot))>4500000)throw new Error('This review exceeds the browser session storage budget. Import fewer or smaller files.');
      await session.remove(['review','journal','publishOptions','pending']);
      await session.set({review});
    } else if(m.type==='publish') {
      const a=await api(),s=await session.get(['review','snapshot','journal','publishOptions']);
      if(!s.review||s.review.id!==m.reviewId)throw new Error('Review the current changes before publishing.');
      if(!s.snapshot || s.review.snapshotKey!==[s.snapshot.fullName,s.snapshot.branch,s.snapshot.sha].join(':'))throw new Error('The repository changed after this review. Review again.');
      const options=s.publishOptions||{branch:String(m.branch||'').trim(),title:String(m.title||'').trim(),message:String(m.message||'').trim(),body:String(m.body||'').slice(0,30000),draft:Boolean(m.draft)};
      await session.set({publishOptions:options});
      const journal=s.journal||{};
      let published;
      try {published=await publishReview(a.api,{...s.review,snapshot:s.snapshot},options,a.auth.login,{journal,checkpoint:async value=>session.set({journal:value})});}
      catch(e){if(!journal.commit)await session.remove(['journal','publishOptions']);throw e;}
      await session.set({published});await session.remove(['review','journal','publishOptions','ci']);
    } else if(m.type==='ci') {
      const a=await api(),{published}=await session.get('published');
      if(!published)throw new Error('Create a PR first.');
      const ci=await readCI(a.api,published);await session.set({ci});
    } else throw new Error('Unknown operation.');
  } finally {busy=false;}
  return view();
}

chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(m?.type==='capture') {
    if(!sender.tab || !sender.url?.startsWith('https://chatgpt.com/'))return false;
    if(typeof m.text!=='string'||bytes(m.text)>MAX_TOTAL_BYTES){respond({ok:false,error:'Response exceeds 3 MiB.'});return false;}
    // Must call open synchronously with the user's content-script click gesture.
    chrome.sidePanel.open({tabId:sender.tab.id}).catch(()=>{});
    session.set({pending:{text:m.text,sourceUrl:sender.url,capturedAt:Date.now()}}).then(()=>respond({ok:true})).catch(e=>respond({ok:false,error:e.message}));
    return true;
  }
  if(sender.id!==chrome.runtime.id || sender.url!==chrome.runtime.getURL('panel.html'))return false;
  handle(m).then(value=>respond({ok:true,value})).catch(e=>respond({ok:false,error:e.message}));
  return true;
});
